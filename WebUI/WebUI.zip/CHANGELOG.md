# Changelog

## 10.1.0

-   Update to PrimeReact 10.2.1

## 10.0.0

-   Upgrade to Next 13.4.8
-   Migrate to Next App Roter
-   Migrate to PrimeReactContext
-   Update to PrimeReact 9.6.2
-   Update other dependencies

## 9.1.2

-   Refactored project files

## 9.1.1

-   Fixed hydration warnings

## 9.1.0

-   Add typescript support

## 9.0.0

-   Upgrade PrimeReact to v9
-   Upgrade to PrimeReact 9.2.2
-   Upgrade to PrimeFlex 3.3.0
-   Upgrade to Next 13.2.3
-   Update other dependencies

## 8.1.0

-   Migrate CRA to NextJS
