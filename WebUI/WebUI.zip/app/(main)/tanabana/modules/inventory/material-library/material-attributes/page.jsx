export default function Page() {
    return <h1>Hello, Tana Bana administration - material-attributes setup page!</h1>
  }