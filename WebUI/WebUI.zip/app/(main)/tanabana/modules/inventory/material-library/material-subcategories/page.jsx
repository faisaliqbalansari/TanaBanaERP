export default function Page() {
    return <h1>Hello, Tana Bana administration - material-subcategories setup page!</h1>
  }