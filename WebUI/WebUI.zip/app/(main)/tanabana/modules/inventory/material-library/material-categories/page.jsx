export default function Page() {
    return <h1>Hello, Tana Bana administration - material-categories setup page!</h1>
  }