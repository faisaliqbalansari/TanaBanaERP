export default function Page() {
    return <h1>Hello, Tana Bana administration -  design-types setup page!</h1>
  }