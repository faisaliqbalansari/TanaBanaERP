export default function Page() {
    return <h1>Hello, Tana Bana administration - R&D setup page!</h1>
  }