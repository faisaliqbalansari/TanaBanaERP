'use client';
import React, { useState, useEffect, useCallback } from 'react';
import Link from "next/link";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputTextarea } from "primereact/inputtextarea";
import { Galleria } from 'primereact/galleria';
import { useForm, Controller } from 'react-hook-form';
import { Checkbox } from 'primereact/checkbox';
import { useToast } from '@/layout/context/toastcontext';
import { ProductService } from '@/app/(main)/tanabana/services/inventory/product-library/products/ProductService.tsx';
import { useConfirmDialog } from '@/layout/context/confirmdialogcontext';
import { ProductSubcategoriesService } from '@/app/(main)/tanabana/services/inventory/product-library/product-subcategories/ProdcutSubcategoriesService';
import { ProductCategoriesService } from '@/app/(main)/tanabana/services/inventory/product-library/product-categories/ProductCategoriesService.tsx';
import { UnitOfMeasureService } from '@/app/(main)/tanabana/services/administration/master-setup/unit-of-measure/UnitOfMeasureService.tsx';

import CustomBreadCrumb from "@/app/(main)/tanabana/common/components/BreadCrumb";

function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [unitsOfMeasure, setUnitsOfMeasure] = useState([]);
  const [categories, setCategories] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState('add'); // 'add' or 'edit'
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubcategory, setSelectedSubcategory] = useState('');
  const [selectedUnit, setSelectedUnit] = useState('');
  const [selectedDiscontinued, setSelectedDiscontinued] = useState('');
  const [value, setValue] = useState(null);
  const [checked, setChecked] = useState(false);

  const service = new ProductService();
  const subcategoryService = new ProductSubcategoriesService();
  const categoryService = new ProductCategoriesService();
  const unitService = new UnitOfMeasureService();

  const { success, error, warn } = useToast();
  const { show } = useConfirmDialog();

  const navItems = [
    { label: 'Administration' },
    { label: 'ERP Master Setup' },
    {
      label: 'Products',
      template: () => <Link href="/tanabana/modules/administration/master-setup/products"><p className="">Products</p></Link>
    }
  ];

  const { control, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: {
      code: '',
      name: '',
      description: '',
      categoryId: null,
      subcategoryId: null,
      productURL: '',
      unitOfMeasureId: null,
      discontinued: null
    }
  });

  const [images, setImages] = useState(null);
  const imageData = [
    {
      itemImageSrc: '/demo/images/saree/SR01.jpg',
      thumbnailImageSrc: '/demo/images/saree/SR01.jpg',
      alt: '',
      title: 'Image 1'
    },
    {
      itemImageSrc: '/demo/images/saree/SR02.jpg',
      thumbnailImageSrc: '/demo/images/saree/SR02.jpg',
      alt: '',
      title: 'Image 2'
    },
    {
      itemImageSrc: '/demo/images/saree/SR03.jpg',
      thumbnailImageSrc: '/demo/images/saree/SR03.jpg',
      alt: '',
      title: 'Image 3'
    },

  ];

  const responsiveOptions = [
    {
      breakpoint: '991px',
      numVisible: 4
    },
    {
      breakpoint: '767px',
      numVisible: 3
    },
    {
      breakpoint: '575px',
      numVisible: 1
    }
  ];

  const itemTemplate = (item) => {
    return <img src={item.itemImageSrc} alt={item.alt} style={{
      borderRadius: '10px',
      border: '1px solid silver', height: '400px', width: '100%', display: 'block'
    }} />;
  }

  const thumbnailTemplate = (item) => {
    return <img src={item.thumbnailImageSrc} alt={item.alt} style={{ width: '40px', display: 'block' }} />;
  }

  useEffect(() => {
    loadProducts();
    loadDropdownOptions();
    setImages(imageData);
  }, []);

  const loadProducts = useCallback(() => {
    service.getProducts()
      .then((productsData) => {
        setProducts(productsData);
      })
      .catch(() => {
        error('Product', 'Error loading products');
      });
  }, [service, error]);

  const loadDropdownOptions = useCallback(async () => {
    try {
      const [units, cats, subs] = await Promise.all([
        unitService.getUnitOfMeasures(),
        categoryService.getProductCategories(),
        subcategoryService.getProductSubcategories()
      ]);
      setUnitsOfMeasure(units);
      setCategories(cats);
      setSubcategories(subs);

    } catch {
      
      error('Product', 'Error loading dropdown options');
    }
  }, [unitService, categoryService, subcategoryService, error]);

  const filteredProducts = products.filter(product =>
    product.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openEditDialog = useCallback((product) => {
    reset({
      code: product.code,
      name: product.name,
      description: product.description,
      categoryId: product.categoryId,
      subcategoryId: product.subcategoryId,
      productURL: product.productURL,
      unitOfMeasureId: product.unitOfMeasureId,
      discontinued: product.discontinued
    });

    setSelectedCategory(categories.find(cat => cat.id === product.categoryId));
    setSelectedSubcategory(subcategories.find(sub => sub.id === product.subcategoryId));
    setSelectedUnit(unitsOfMeasure.find(units => units.id === product.unitOfMeasureId));

    setSelectedRowData(product);
    setDialogMode('edit');
    setShowDialog(true);
  }, [reset, categories, subcategories, unitsOfMeasure,]);


  const openAddDialog = () => {
    reset({
      code: '',
      name: '',
      description: '',
      categoryId: null,
      subcategoryId: null,
      productURL: '',
      unitOfMeasureId: null,
      discontinued: null
    });

    setSelectedRowData(null);
    setSelectedCategory(null);
    setSelectedUnit(null);
    setSelectedDiscontinued(null);
    setSelectedSubcategory(null);
    setDialogMode('add');
    setShowDialog(true);
  };

  const onSubmit = async (data) => {
    if (!data.code || !data.name) {
      error('Product', 'All fields are required');
      return;
    }

    const productData = {
      code: data.code,
      name: data.name,
      description: data.description,
      categoryId: selectedCategory.id,
      subcategoryId: selectedSubcategory.id,
      productURL: data.productURL,
      unitOfMeasureId: selectedUnit.id,
      discontinued: data.discontinued,
      id: selectedRowData ? selectedRowData.id : 0
    };

    try {
      await service.saveProduct(productData);
      success('Product', selectedRowData ? 'Product updated successfully' : 'Product added successfully');
      loadProducts();
      setShowDialog(false);
      reset();
    } catch {
      error('Product', 'Error saving product');
    }
  };

  const textEditor = (options) => {
    return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} />;
  };

  const deleteRow = (rowData) => {
    show(
      'Are you sure you want to delete this product?',
      () => {
        service.deleteProduct(rowData.id)
          .then(() => {
            success('Product', 'Product deleted successfully');
            loadProducts();
          })
          .catch(() => {
            warn('Product', 'Product cannot be deleted');
          });
      },
      () => { }
    );
  };

  const confirmDelete = () => {
    if (selectedRowData) {
      service.deleteProduct(selectedRowData.id)
        .then(() => {
          success("Product", "Product deleted successfully");
          loadProducts();
        })
        .catch(() => {
          warn('Product', 'Product cannot be deleted');
        });
    }
    setDeleteConfirmation(false);
  };

  const cancelDelete = () => {
    setDeleteConfirmation(false);
    setSelectedRowData(null);
  };

  const headerTemplate = (options) => {
    const className = `${options.className} justify-content-space-between`;

    return (
      <div className={className}>
        <div className="flex align-items-center gap-2">
          <span className="font-bold">Products</span>
        </div>
        <div className='text-right'>
          <InputText
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search..."
            className="ml-2 p-1 mr-3"
          />
          <Button className="p-2 mr-3 p-button-secondary" label="Add New" onClick={openAddDialog} />
          {options.togglerElement}
        </div>
      </div>
    );
  };

  const deleteTemplate = (rowData) => {
    return (
      <span className="p-cursor-pointer" onClick={() => deleteRow(rowData)} style={{ cursor: 'pointer' }}>
        <i className="pi pi-trash" />
      </span>
    );
  };

  const editTemplate = (rowData) => {
    return (
      <span className="p-cursor-pointer" onClick={() => openEditDialog(rowData)} style={{ cursor: 'pointer' }}>
        <i className="pi pi-pencil" />
      </span>
    );
  };

  const onCategoryChange = async (e) => {

    setSelectedCategory(e.value);
    const categoryId = e.value.id;
    const subcategoryList = await subcategoryService.getProductSubcategories(categoryId);
    setSubcategories(subcategoryList);
  };

  const onSubcategoryChange = (e) => {

    setSelectedSubcategory(e.value);

  };
  const onUnitOfMeasureChange = (e) => {
    setSelectedUnit(e.value);
  }
  const onDiscontinuedChange = (e) => {
    setSelectedDiscontinued(e.value);
  }
  const handleCancel = (event) => {
    event.preventDefault();
    event.stopPropagation();
    setShowDialog(false);
  };
  return (
    <div>
      <CustomBreadCrumb navItems={navItems} className="" />

      <Dialog
        visible={showDialog}
        style={{ width: '90vw', height: '90vw' }}
        onHide={() => setShowDialog(false)}
        header={dialogMode === 'edit' ? "Edit Product" : "Add New Product"}
        position="center"
      >
        <form
          style={{ width: '100%', height: '100%' }}
          onSubmit={handleSubmit(onSubmit)} className="p-fluid mt-2">
          <div className='grid'>
            <div className="grid lg:col-8 md:col-6 sm:col-6">
              <div className="mb-0 lg:col-6 md:col-12">
                <label htmlFor="code" className='font-semibold'>Code:</label>
                <Controller
                  name="code"
                  control={control}
                  rules={{ required: 'Code is required' }}
                  render={({ field: { onChange, value } }) => (
                    <InputText
                      id="code"
                      className='mt-1 mb-0 p-2'
                      value={value}
                      onChange={onChange}
                    />
                  )}
                />
                {errors.code && <small className="p-error">{errors.code?.message}</small>}
              </div>
              <div className="mb-0 lg:col-6 md:col-12">
                <label htmlFor="name" className='font-semibold'>Name:</label>
                <Controller
                  name="name"
                  control={control}
                  rules={{ required: 'Name is required' }}
                  render={({ field: { onChange, value } }) => (
                    <InputText
                      id="name"
                      className='mt-1 mb-0 p-2'
                      value={value}
                      onChange={onChange}
                    />
                  )}
                />
                {errors.name && <small className="p-error">{errors.name?.message}</small>}
              </div>
              <div className="mb-0 lg:col-6 md:col-12">
                <label htmlFor="categoryId" className='font-semibold'>Category:</label>
                <Controller
                  name="categoryId"
                  control={control}
                  render={({ field: { onChange, value } }) => (
                    <Dropdown
                      id="categoryId"
                      value={selectedCategory}
                      options={categories}
                      onChange={(e) => onCategoryChange(e)}
                      optionLabel="name"
                      placeholder="Select a Category"
                    />
                  )}
                />
              </div>
              <div className="mb-0 lg:col-6 md:col-12">
                <label htmlFor="subcategoryId" className='font-semibold'>Subcategory:</label>
                <Controller
                  name="subcategoryId"
                  control={control}
                  render={({ field: { onChange, value } }) => (
                    <Dropdown
                      id="subcategoryId"
                      value={selectedSubcategory}
                      options={subcategories}
                      onChange={(e) => onSubcategoryChange(e)}
                      optionLabel="name"
                      placeholder="Select a Subcategory"
                    />
                  )}
                />
              </div>
              <div className="mb-0 lg:col-12 md:col-12">
                <label htmlFor="productURL" className='font-semibold'>Product URL:</label>
                <Controller
                  name="productURL"
                  control={control}
                  render={({ field: { onChange, value } }) => (
                    <InputText
                      id="productURL"
                      className='mt-1 mb-0 p-2'
                      value={value}
                      onChange={onChange}
                    />
                  )}
                />
              </div>
              <div className="mb-0 lg:col-6 md:col-8">
                <label htmlFor="unitOfMeasureId" className='font-semibold'>Unit Of Measure:</label>
                <Controller
                  name="unitOfMeasureId"
                  control={control}
                  render={({ field: { onChange, value } }) => (
                    <Dropdown
                      id="unitOfMeasureId"
                      value={selectedUnit}
                      options={unitsOfMeasure}
                      onChange={(e) => onUnitOfMeasureChange(e)}
                      optionLabel="name"
                      placeholder="Select a Unit of Measure"
                    />
                  )}
                />
              </div>
              <div className=" lg:col-6 md:col-4">
                <label htmlFor="discontinued" className='font-semibold'>Discounted:</label>
                <Controller
                  name="discontinued"
                  control={control}
                  render={({ field: { onChange, value } }) => (
                    <Checkbox
                      id="discontinued"
                      className="ml-2 mt-4"
                      checked={value}
                      onChange={(e) => onChange(e.checked)}
                    />
                  )}
                />

              </div>
              <div className="mb-0 col-12">
                <label htmlFor="description" className='font-semibold'>Description:</label>
                <Controller
                  name="description"
                  control={control}
                  render={({ field: { onChange, value } }) => (
                    <InputTextarea autoResize id='description' value={value} onChange={onChange} rows={5} cols={30} />
                  )}
                />
              </div>
            </div>
            <div className="grid lg:col-4 md:col-6 sm:col-6">
              <div className="mb-0 col-12">
                <label htmlFor="productImage" className='mt-2 font-semibold'>Product Images:</label>
                <div className="cardss p-1">
                  <Galleria value={images} numVisible={5} circular style={{ maxWidth: '640px' }}
                    showItemNavigators autoPlay transitionInterval={2000}
                    showThumbnails={false} item={itemTemplate} thumbnail={thumbnailTemplate} />

                </div>
              </div>
            </div>
          </div>
          <div
            style={{ bottom: '10px', position: 'absolute', right: '25px' }}
            className="mb-3 p-d-flex p-jc-end text-right">
            <Button type="submit" label="Save" icon="pi pi-check" className="p-button-secondary mt-3 col-3 mr-1" />
            <Button label="Cancel" icon="pi pi-times" className="p-button-secondary p-ml-2 mt-3 col-3" outlined onClick={handleCancel} />
          </div>
        </form>
      </Dialog>

      <ConfirmDialog
        visible={deleteConfirmation}
        onHide={() => setDeleteConfirmation(false)}
        message="Are you sure you want to delete this product?"
        header="Confirm"
        icon="pi pi-info-circle"
        accept={confirmDelete}
        reject={cancelDelete}
      />

      <div className='pt-3 p-3'>
        <Panel headerTemplate={headerTemplate} >
          <div className="p-2 rounded-corner">
            <DataTable value={filteredProducts}
              scrollable
              scrollHeight="calc(100vh - 200px)"
              editMode="row"
              dataKey="id"
              tableStyle={{ minWidth: 'calc(100% - 300px)' }}
            >
              <Column field="categoryName" header="Category" editor={textEditor} style={{ width: 'calc(20% - 175px)' }}></Column>
              <Column field="subcategoryName" header="Subcategory" editor={textEditor} style={{ width: 'calc(35% - 175px)' }}></Column>
              <Column field="code" header="Product Code" editor={textEditor} style={{ width: 'calc(20% - 175px)' }}></Column>
              <Column field="name" header="Product Name" editor={textEditor} style={{ width: 'calc(35% - 175px)' }}></Column>
              <Column field="description" header="Description" editor={textEditor} style={{ maxWidth: '220px', width: 'calc(45% - 175px)' }}></Column>
              <Column field="unitOfMeasure" header="Unit of Measure" editor={textEditor} style={{ width: 'calc(20% - 175px)' }}></Column>
              <Column body={editTemplate} headerStyle={{ width: '100px', minWidth: '100px' }} bodyStyle={{ textAlign: 'right' }}></Column>
              <Column body={deleteTemplate} headerStyle={{ width: '40px', minWidth: '40px' }} bodyStyle={{ textAlign: 'left' }}></Column>
            </DataTable>
          </div>
        </Panel>
      </div>
    </div>
  );
}

export default ProductsPage;
