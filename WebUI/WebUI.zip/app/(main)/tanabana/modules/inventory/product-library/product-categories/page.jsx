'use client';
import React, { useState, useEffect } from 'react';
import Link from "next/link";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';
import { InputText } from 'primereact/inputtext';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { useForm, Controller } from 'react-hook-form';
import { useToast } from '@/layout/context/toastcontext';
import { ProductCategoriesService } from '@/app/(main)/tanabana/services/inventory/product-library/product-categories/ProductCategoriesService.tsx';
import { useConfirmDialog } from '@/layout/context/confirmdialogcontext'; 

import CustomBreadCrumb from "@/app/(main)/tanabana/common/components/BreadCrumb";

function ProductCategoriesPage() {
  const [categories, setCategories] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState('add'); // 'add' or 'edit'
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const service = new ProductCategoriesService();
  const { success, error, warn } = useToast();
  const {show} = useConfirmDialog();

  const navItems = [
    { label: 'Administration' },
    { label: 'ERP Master Setup' },
    {
      label: 'Product Categories',
      template: () => <Link href="/tanabana/modules/administration/master-setup/product-categories"><p className="">Product Categories</p></Link>
    }
  ];

  const { control, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: {
      newCategoryCode: '',
      newCategoryName: '',
      newCategoryDescription: '',
      parentCategoryId: 0,
      isMaterialCategory: false
    }
  });

  useEffect(() => {
    loadProductCategories();
  }, []);

  const loadProductCategories = () => {
    service.getProductCategories()
      .then((categoriesData) => {
        setCategories(categoriesData);
      })
      .catch(() => {
        error('Product Category', 'Error loading product categories');
      });
  };

  const filteredProductCategories = categories.filter(category =>
    category.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    category.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openEditDialog = (category) => {
    reset({
      newCategoryCode: category.code,
      newCategoryName: category.name,
      newCategoryDescription: category.description,
      parentCategoryId: category.parentCategoryId,
      isMaterialCategory: category.isMaterialCategory
    });

    setSelectedRowData(category);
    setDialogMode('edit');
    setShowDialog(true);
  };

  const openAddDialog = () => {
    reset({
      newCategoryCode: '',
      newCategoryName: '',
      newCategoryDescription: '',
      parentCategoryId: 0,
      isMaterialCategory: false
    });

    setSelectedRowData(null);
    setDialogMode('add');
    setShowDialog(true);
  };

  const onSubmit = async (data) => {
    if (!data.newCategoryCode || !data.newCategoryName) {
      error('Product Category', 'All fields are required');
      return;
    }

    const categoryData = {
      code: data.newCategoryCode,
      name: data.newCategoryName,
      description: data.newCategoryDescription,
      parentCategoryId: data.parentCategoryId,
      isMaterialCategory: data.isMaterialCategory,
      id: selectedRowData ? selectedRowData.id : 0
    };

    try {
      await service.saveProductCategories(categoryData);
      success('Product Category', selectedRowData ? 'Product Category updated successfully' : 'Product Category added successfully');
      loadProductCategories();
      setShowDialog(false);
      reset();
    } catch {
      error('Product Category', 'Error saving Product Category');
    }
  };

  const textEditor = (options) => {
    return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} />;
  };

  const deleteRow = (rowData) => {
    show(
      'Are you sure you want to delete this category?',
      () => {
        service.deleteProductCategories(rowData.id)
          .then(() => {
            success('Category', 'category deleted successfully');
            loadProductCategories();
          })
          .catch(() => {
            warn('Category', 'category cannot be deleted');
          });
      },
      () => {}
    );
  };
  const confirmDelete = () => {
    if (selectedRowData) {
      service.deleteProductCategories(selectedRowData.id)
        .then(() => {
          success("Product Category", "Product Category deleted successfully");
          loadProductCategories();
        })
        .catch(() => {
          warn('Product Category', 'Product Category cannot be deleted');
        });
    }
    setDeleteConfirmation(false);
  };

  const cancelDelete = () => {
    setDeleteConfirmation(false);
    setSelectedRowData(null);
  };

  const headerTemplate = (options) => {
    const className = `${options.className} justify-content-space-between`;

    return (
      <div className={className}>
        <div className="flex align-items-center gap-2">
          <span className="font-bold">Product Categories</span>
        </div>
        <div className='text-right'>
          <InputText
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search..."
            className="ml-2 p-1 mr-3"
          />
          <Button className="p-2 mr-3 p-button-secondary" label="Add New" onClick={openAddDialog} />
          {options.togglerElement}
        </div>
      </div>
    );
  };

  const deleteTemplate = (rowData) => {
    return (
      <span className="p-cursor-pointer" onClick={() => deleteRow(rowData)} style={{ cursor: 'pointer' }}>
        <i className="pi pi-trash" />
      </span>
    );
  };

  const editTemplate = (rowData) => {
    return (
      <span className="p-cursor-pointer" onClick={() => openEditDialog(rowData)} style={{ cursor: 'pointer' }}>
        <i className="pi pi-pencil" />
      </span>
    );
  };

  return (
    <div>
      <CustomBreadCrumb navItems={navItems} className="" />

      <Dialog
        visible={showDialog}
        style={{ width: '50vw' }}
        onHide={() => setShowDialog(false)}
        header={dialogMode === 'edit' ? "Edit Product Category" : "Add New Product Category"}
        position="center"
      >
        <form onSubmit={handleSubmit(onSubmit)} className="p-fluid mt-2">
          <div className="mb-2">
            <label htmlFor="newCategoryCode" className='font-semibold'>Code:</label>
            <Controller
              name="newCategoryCode"
              control={control}
              rules={{ required: 'Code is required' }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newCategoryCode"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
            {errors.newCategoryCode && <small className="p-error">{errors.newCategoryCode?.message}</small>}
          </div>
          <div className="mb-2">
            <label htmlFor="newCategoryName" className='font-semibold'>Name:</label>
            <Controller
              name="newCategoryName"
              control={control}
              rules={{ required: 'Name is required' }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newCategoryName"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
            {errors.newCategoryName && <small className="p-error">{errors.newCategoryName?.message}</small>}
             <div className="mb-2">
            <label htmlFor="newCategoryName" className='font-semibold'>Description</label>
              <Controller
              name="newCategoryDescription"
              control={control}
              rules={{ required: 'Description is required' }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newCategoryDescription"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
            {errors.newCategoryDescription && <small className="p-error">{errors.newCategoryDescription?.message}</small>}
          </div>
        </div>
          <div className="p-mt-3 p-d-flex p-jc-end text-right">
            <Button type="submit" label="Save" icon="pi pi-check" className="p-button-secondary mt-3 col-3 mr-1" />
            <Button label="Cancel" icon="pi pi-times" className="p-button-secondary p-ml-2 mt-3 col-3" outlined onClick={() => setShowDialog(false)} />
          </div>
        </form>
      </Dialog>

      <div className='pt-3 p-3'>
      <Panel headerTemplate={headerTemplate} >
          <div className="p-2 rounded-corner">
            <DataTable value={filteredProductCategories}
              scrollable
              scrollHeight="calc(100vh - 200px)"
              editMode="row"
              selection={selectedCategory}
              onSelectionChange={(e) => setSelectedCategory(e.value)}
              dataKey="id"
              tableStyle={{ minWidth: 'calc(100% - 300px)' }}
              >
              <Column field="code" header="Code" editor={(options) => textEditor(options)} style={{ width: 'calc(20% - 175px)' }}></Column>
              <Column field="name" header="Name" editor={(options) => textEditor(options)} style={{ width: 'calc(35% - 175px)' }}></Column>
              <Column field="description" header="Description" editor={(options) => textEditor(options)} style={{ width: 'calc(45% - 175px)' }}></Column>
              <Column body={editTemplate} headerStyle={{ width: '100px', minWidth: '100px' }} bodyStyle={{ textAlign: 'right' }}></Column>
              <Column body={deleteTemplate} headerStyle={{ width: '40px', minWidth: '40px' }} bodyStyle={{ textAlign: 'left' }}></Column>
            </DataTable>
          </div>
        </Panel>
      </div>

      <ConfirmDialog
        visible={deleteConfirmation}
        onHide={() => setDeleteConfirmation(false)}
        message="Are you sure you want to delete this category?"
        header="Confirmation"
        icon="pi pi-exclamation-triangle"
        accept={confirmDelete}
        reject={cancelDelete}
      />
    </div>
  );
}

export default ProductCategoriesPage;

