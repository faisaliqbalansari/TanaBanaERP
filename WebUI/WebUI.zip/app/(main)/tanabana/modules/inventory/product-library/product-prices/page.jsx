export default function Page() {
  return <h1>Hello, Tana Bana Product Price Page!</h1>
}