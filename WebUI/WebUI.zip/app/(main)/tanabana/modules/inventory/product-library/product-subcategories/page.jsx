'use client';
import React, { useState, useEffect } from 'react';
import Link from "next/link";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';
import { InputText } from 'primereact/inputtext';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { useForm, Controller } from 'react-hook-form';
import { useToast } from '@/layout/context/toastcontext';
import { ProductSubcategoriesService } from '@/app/(main)/tanabana/services/inventory/product-library/product-subcategories/ProdcutSubcategoriesService';
import { ProductCategoriesService } from '@/app/(main)/tanabana/services/inventory/product-library/product-categories/ProductCategoriesService.tsx';
import { useConfirmDialog } from '@/layout/context/confirmdialogcontext';

import CustomBreadCrumb from "@/app/(main)/tanabana/common/components/BreadCrumb";

function ProductSubcategoriesPage() {
  const [subcategories, setSubcategories] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selectedSubcategory, setSelectedSubcategory] = useState(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState('add');
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const subcategoryService = new ProductSubcategoriesService();
  const categoryService = new ProductCategoriesService();
  const { success, error, warn } = useToast();
  const {show} = useConfirmDialog();

  const navItems = [
    { label: 'Administration' },
    { label: 'ERP Master Setup' },
    {
      label: 'Product Subcategories',
      template: () => <Link href="/tanabana/modules/administration/master-setup/product-subcategories"><p className="">Product Subcategories</p></Link>
    }
  ];

  const { control, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: {
      newSubcategoryCode: '',
      newSubcategoryName: '',
      parentCategoryId:null,
      isMaterialSubcategory: false,
      newSubcategoryDescription: ''
    }
  });


  useEffect(() => {
    loadProductSubcategories();
    loadProductCategories();
  }, []);

  const loadProductSubcategories = () => {
    subcategoryService.getProductSubcategories()
      .then((subcategoriesData) => {
        setSubcategories(subcategoriesData);
      })
      .catch(() => {
        error('Product Subcategory', 'Error loading product subcategories');
      });
  };

  const loadProductCategories = () => {
    categoryService.getProductCategories()
      .then((categoriesData) => {
        setCategories(categoriesData);
      })
      .catch(() => {
        error('Product Category', 'Error loading product categories');
      });
  };

  const filteredProductSubcategories = subcategories.filter(subcategory =>
    subcategory.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    subcategory.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openEditDialog = (subcategory) => {
    reset({
      newSubcategoryCode: subcategory.code || '',
      newSubcategoryName: subcategory.name || '',
      parentCategoryId: subcategory.categoryId || null, 
      isMaterialSubcategory: subcategory.isMaterialSubcategory || false,
      newSubcategoryDescription: subcategory.description || ''
    });
  
    setSelectedRowData(subcategory);
    setDialogMode('edit');
    setShowDialog(true);
  };
  
  const openAddDialog = () => {
    reset({
      newSubcategoryCode: '',
      newSubcategoryName: '',
      parentCategoryId: null,
      isMaterialSubcategory: false,
      newSubcategoryDescription: ''
    });
  
    setSelectedRowData(null);
    setDialogMode('add');
    setShowDialog(true);
  };
  
  const onSubmit = async (data) => {
    if (!data.newSubcategoryCode || !data.newSubcategoryName) {
      error('Product Subcategory', 'All fields are required');
      return;
    }

    const subcategoryData = {
      code: data.newSubcategoryCode,
      name: data.newSubcategoryName,
      parentCategoryId: data.category.id,
      isMaterialSubcategory: data.isMaterialSubcategory,
      description: data.newSubcategoryDescription,
      id: selectedRowData ? selectedRowData.id : 0
    };

    try {
      await subcategoryService.saveProductSubcategories(subcategoryData);
      success('Product Subcategory', selectedRowData ? 'Product Subcategory updated successfully' : 'Product Subcategory added successfully');
      loadProductSubcategories();
      setShowDialog(false);
      reset();
    } catch {
      error('Product Subcategory', 'Error saving Product Subcategory');
    }
  };

  const textEditor = (options) => {
    return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} />;
  };

  const deleteRow = (rowData) => {
    show(
      'Are you sure you want to delete this subcategory?',
      () => {
        subcategoryService.deleteProductSubcategories(rowData.id)
          .then(() => {
            success('Subcategory', 'subcategory deleted successfully');
            loadProductSubcategories();
          })
          .catch(() => {
            warn('Subcategory', 'subcategory cannot be deleted');
          });
      },
      () => {}
    );
  };


  const confirmDelete = () => {
    if (selectedRowData) {
      subcategoryService.deleteProductSubcategories(selectedRowData.id)
        .then(() => {
          success("Product Subcategory", "Product Subcategory deleted successfully");
          loadProductSubcategories();
        })
        .catch(() => {
          warn('Product Subcategory', 'Product Subcategory cannot be deleted');
        });
    }
    setDeleteConfirmation(false);
  };

  const cancelDelete = () => {
    setDeleteConfirmation(false);
    setSelectedRowData(null);
  };

  const headerTemplate = (options) => {
    const className = `${options.className} justify-content-space-between`;

    return (
      <div className={className}>
        <div className="flex align-items-center gap-2">
          <span className="font-bold">Product Subcategories</span>
        </div>

        <div className='text-right'>
            <InputText
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search..."
                className="ml-2 p-1 mr-3"
            />
          <Button className="p-2 mr-3 p-button-secondary" label="Add New" onClick={openAddDialog} />
          {options.togglerElement}
        </div>
      </div>
    );
  };

  const deleteTemplate = (rowData) => {
    return (
      <span className="p-cursor-pointer" onClick={() => deleteRow(rowData)} style={{ cursor: 'pointer' }}>
        <i className="pi pi-trash" />
      </span>
    );
  };

  const editTemplate = (rowData) => {
    return (
      <span className="p-cursor-pointer" onClick={() => openEditDialog(rowData)} style={{ cursor: 'pointer' }}>
        <i className="pi pi-pencil" />
      </span>
    );
  };

  return (
    <div>
      <CustomBreadCrumb navItems={navItems} className="" />

      <Dialog
        visible={showDialog}
        style={{ width: '50vw' }}
        onHide={() => setShowDialog(false)}
        header={dialogMode === 'edit' ? "Edit Product Subcategory" : "Add New Product Subcategory"}
        position="center"
      >
        <form onSubmit={handleSubmit(onSubmit)} className="p-fluid mt-2">
          <div className="mb-2">
            <label htmlFor="newSubcategoryCode" className='font-semibold'>Code:</label>
            <Controller
              name="newSubcategoryCode"
              control={control}
              rules={{ required: 'Code is required' }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newSubcategoryCode"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
            {errors.newSubcategoryCode && <small className="p-error">{errors.newSubcategoryCode?.message}</small>}
          </div>
          <div className="mb-2">
            <label htmlFor="newSubcategoryName" className='font-semibold'>Name:</label>
            <Controller
              name="newSubcategoryName"
              control={control}
              rules={{ required: 'Name is required' }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newSubcategoryName"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
            {errors.newSubcategoryName && <small className="p-error">{errors.newSubcategoryName?.message}</small>}
          </div>
          <div className="mb-2">
            <label htmlFor="category" className='font-semibold'>Category:</label>
            <Controller
              name="category"
              control={control}
              rules={{ required: 'Category is required' }}
              render={({ field: { onChange, value } }) => (
                <Dropdown
                  id="category"
                  value={value || null} 
                  options={categories}
                  onChange={(e) => onChange(e.value)}
                  optionLabel="name"
                  placeholder="Select a Category"
                />
              )}
            />

            {errors.categoryId && <small className="p-error">{errors.categoryId?.message}</small>}
          </div>
          <div className="mb-2">
            <label htmlFor="newSubcategoryDescription" className='font-semibold'>Description:</label>
            <Controller
              name="newSubcategoryDescription"
              control={control}
              rules={{ required: 'Description is required' }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newSubcategoryDescription"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
            {errors.newSubcategoryDescription && <small className="p-error">{errors.newSubcategoryDescription?.message}</small>}
          </div>
          <div className="p-mt-3 p-d-flex p-jc-end text-right">
            <Button type="submit" label="Save" icon="pi pi-check" className="p-button-secondary mt-3 col-3 mr-1" />
            <Button label="Cancel" icon="pi pi-times" className="p-button-secondary p-ml-2 mt-3 col-3" outlined onClick={() => setShowDialog(false)} />
          </div>
        </form>
      </Dialog>

      <div className='pt-3 p-3'>
        <Panel headerTemplate={headerTemplate} >
          <div className="p-2 rounded-corner">
            <DataTable value={filteredProductSubcategories}
              scrollable
              scrollHeight="calc(100vh - 200px)"
              editMode="row"
              selection={selectedSubcategory}
              onSelectionChange={(e) => setSelectedSubcategory(e.value)}
              dataKey="id"
              tableStyle={{ minWidth: 'calc(100% - 300px)' }}
            >
              <Column field="parentCategoryName" header="Category" style={{ width: '20%' }}></Column>
              <Column field="code" header="Code" editor={(options) => textEditor(options)} style={{ width: 'calc(20% - 175px)' }}></Column>
              <Column field="name" header="Name" editor={(options) => textEditor(options)} style={{ width: 'calc(35% - 175px)' }}></Column>
              <Column field="description" header="Description" editor={(options) => textEditor(options)} style={{ width: 'calc(45% - 175px)' }}></Column>
              <Column body={editTemplate} headerStyle={{ width: '100px', minWidth: '100px' }} bodyStyle={{ textAlign: 'right' }}></Column>
              <Column body={deleteTemplate} headerStyle={{ width: '40px', minWidth: '40px' }} bodyStyle={{ textAlign: 'left' }}></Column>
            </DataTable>
          </div>
        </Panel>
      </div>
   
      <ConfirmDialog
        visible={deleteConfirmation}
        onHide={() => setDeleteConfirmation(false)}
        message="Are you sure you want to delete this subcategory?"
        header="Confirmation"
        icon="pi pi-exclamation-triangle"
        accept={confirmDelete}
        reject={cancelDelete}
      />
    </div>
  );
}

export default ProductSubcategoriesPage;
