export default function Page() {
    return <h1>Hello, Tana Bana administration - user setup page!</h1>
  }