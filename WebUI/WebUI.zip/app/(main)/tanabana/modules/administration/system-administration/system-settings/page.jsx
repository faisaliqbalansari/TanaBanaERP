export default function Page() {
    return <h1>Hello, Tana Bana administration - system-settings setup page!</h1>
  }