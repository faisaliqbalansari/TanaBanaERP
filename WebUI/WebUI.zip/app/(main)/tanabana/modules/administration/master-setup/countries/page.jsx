'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { useToast } from '@/layout/context/toastcontext';

import CustomBreadCrumb from '@/app/(main)/tanabana/common/components/BreadCrumb';
import { CountryService } from '@/app/(main)/tanabana/services/administration/master-setup/countries/CountryService.tsx';

import TBFormDialog from '@/app/(main)/tanabana/common/components/tanabana-form-dialog';
import TBAlertDialog from '@/app/(main)/tanabana/common/components/tanabana-alert-dialog';
import TBDataTable from '@/app/(main)/tanabana/common/components/tanabana-data-table';
import { editTemplate, deleteTemplate, headerTemplate, filterData } from '@/app/(main)/tanabana/common/components/tanabana-data-table/tableTemplates';

function Countries() {
    const [countries, setCountries] = useState([]);
    const [selectedCountry, setSelectedCountry] = useState(null);
    const [deleteConfirmation, setDeleteConfirmation] = useState(false);
    const [selectedRowData, setSelectedRowData] = useState(null);
    const [searchQuery, setSearchQuery] = useState('');
    const [showNewCountryDialog, setShowNewCountryDialog] = useState(false);
    const [loading, setLoading] = useState(true);
    const { success, error, warn } = useToast();
    const service = new CountryService();

    const navItems = [
        { label: 'Administration' },
        { label: 'ERP Master Setup' },
        {
            label: 'Countries',
            template: () => (
                <Link href="/tanabana/modules/administration/master-setup/countries">
                    <p className="">Countries</p>
                </Link>
            )
        }
    ];

    ////////////////////////////////////// OPEN / CLOSE DIALOG HANDLERS //////////////////////////////////
    const DialogConfig = {
        dialog: showNewCountryDialog,
        setDialog: setShowNewCountryDialog
    };

    ////////////////////////////////////// OPEN / CLOSE ALERT DIALOG HANDLERS //////////////////////////////////
    const ConfirmationDialogConfig = {
        dialog: deleteConfirmation,
        setDialog: setDeleteConfirmation
    };

    ////////////////////////////////////// SELECT / UNSELECT TABLE DATA HANDLERS //////////////////////////////////
    const TableSelectedData = {
        selectedData: selectedCountry,
        setSelectedData: setSelectedCountry
    };
  
    ////////////////////////////////////// ADD / EDIT FORM FIELDS DATA //////////////////////////////////
    const Fields = [
        {
            Id: 'newCountryCode',
            Label: 'Code',
            FieldType: 'string',
            IsRequired: true,
            Class: ''
        },
        {
            Id: 'newCountryName',
            Label: 'Name',
            FieldType: 'text',
            IsRequired: true,
            Class: ''
        },
        {
            Id: 'newCountryDescription',
            Label: 'Description',
            FieldType: 'text',
            IsRequired: true,
            Class: ''
        }
    ];

    ////////////////////////////////////// ADD / EDIT FORM CONTROLLER //////////////////////////////////
    const {
        control,
        handleSubmit,
        reset,
        formState: { errors }
    } = useForm({
        defaultValues: {
            newCountryCode: '',
            newCountryName: '',
            newCountryDescription: ''
        }
    });

    ////////////////////////////////////// FETCHING COUNTRIES DATA //////////////////////////////////

    const loadCountries = () => {
        try {
         service.getCountries()
         .then((countriesData) => {
           setCountries(countriesData);
         })
         .catch((error) => {
             console.error('Error fetching countries:', error);
         })
            // setCountries(mockCountries);
        } catch (e) {
            error('Country', 'Could Not Get Countries');
        }
    };
    useEffect(() => {
        setLoading(true);
        loadCountries();
        setLoading(false);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);


    const fields = ['code', 'name', 'description'];
    const filteredData = filterData(countries, searchQuery, fields);
    ////////////////////////////////////// DATA TABLE EVENT HANDLERS //////////////////////////////////

    const openEditDialog = (Country) => {
        reset({
            newCountryCode: Country.code,
            newCountryName: Country.name,
            newCountryDescription: Country.description
        });

        setSelectedRowData(Country);
        setShowNewCountryDialog(true);
    };

    const onRowEditComplete = (e) => {
        let updatedCountries = [...countries];
        updatedCountries[e.index] = e.data;

        if (!e.newData.code || !e.newData.name) {
            alert('Rows cannot be empty after editing!');
        } else {
            service
                .saveCountries(e.newData)
                .then(() => {
                    loadCountries();
                })
                .catch((error) => {
                    console.error('Error saving record:', error);
                });
        }
    };

    const onSubmit = async (data) => {
        if (!data.newCountryCode || !data.newCountryName) {
            error('Country', 'All fields are required');
            return;
        }

        const countryData = {
            code: data.newCountryCode,
            name: data.newCountryName,
            description: data.newCountryDescription
        };

        try {
            if (selectedRowData) {
                countryData.id = selectedRowData.id;
                await service.saveCountries(countryData);
                success('Country', 'Record updated successfully');
            } else {
                countryData.id = 0;
                await service.saveCountries(countryData);
                success('Country', 'Record Added successfully');
            }

            loadCountries();
            setShowNewCountryDialog(false);
            reset();
        } catch (e) {
            error('Country', 'Error saving Country');
        }
    };

    const deleteRow = (rowData) => {
        setDeleteConfirmation(true);
        setSelectedRowData(rowData);
    };

    const confirmDelete = () => {
        if (selectedRowData) {
            service
                .deleteCountry(selectedRowData.id)
                .then(() => {
                    success('Country', 'Record deleted successfully');
                    loadCountries();
                })
                .catch((e) => {
                    console.error('Error deleting country:', e);
                    error('Country', 'Error in deleting record');
                });
        }
    };

    ////////////////////////////////////// DATA TABLE TEMPLATES //////////////////////////////////
    const openAddDialog = () => {
        // Reset form values for adding new city
        reset({
            newCountryCode: '',
            newCountryName: '',
            newCountryDescription: ''
        });
        setSelectedRowData(null);
        setShowNewCountryDialog(true);
    };
    ////////////////////////////////////// TABLE HEADER CONFIG //////////////////////////////////
    const TableHeaderConfig = {
        TableName: 'Countries',
        OpenDialog: openAddDialog,
        Searchable: true,
        SearchQuery: searchQuery,
        SetSearchQuery: setSearchQuery
    };
    ////////////////////////////////////// ADD / EDIT DIALOG FORM CONFIGRATION OBJET //////////////////////////////////
    const FormDialogConfig = {
        Id: '',
        FormFields: Fields,
        ImageGallary: null,
        OnSubmit: onSubmit,
        OnCancel: null,
        Class: '',
        DialogConfig: DialogConfig,
        ModelName: selectedRowData ? 'Edit Country' : 'Add New Country',
        FormHandler: { control, handleSubmit, reset, errors },
        ModelPosition: 'center',
        OnSubmitButtonText: selectedRowData ? 'Save' : 'Add',
        OnCanceltButtonText: 'Cancle',
        Height: '80vh',
        Width: '80vw'
    };
    ////////////////////////////////////// ALERT DIALOG CONFIGRATION OBJET //////////////////////////////////
    const AlertDialogConfig = {
        Id: '',
        ConfirmationDialogConfig: ConfirmationDialogConfig,
        Message: 'Are you sure you want to delete this country?',
        HeaderText: 'Confirmation',
        Icon: 'pi pi-exclamation-triangle',
        ConfirmButtonClass: 'p-button-secondary',
        ConfirmIcon: 'pi pi-trash',
        ConfirmButtonLabel: 'Yes',
        RejectButtonClass: 'p-button-secondary',
        RejectButtonLabel: 'No',
        OnConfirm: confirmDelete,
        OnReject: null
    };
    ////////////////////////////////////// COUNTRIES DATA TABLE CONFIGRATION OBJET //////////////////////////////////
    const DataTableConfig = {
        SelectedData: TableSelectedData,
        HeaderTemplate: (option) => headerTemplate(option, TableHeaderConfig),
        DataArray: filteredData,
        OnRowEditComplete: onRowEditComplete,
        loading:loading,
        Columns: [
            { Id: 'code', Field: 'code', Header: 'Code', Type: 'field', Style: { width: 'calc(20% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'name', Field: 'name', Header: 'Name', Type: 'field', Style: { width: 'calc(35% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'description', Field: 'description', Header: 'Description', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'edit', BodyTemplate: (rowData) => editTemplate(rowData, openEditDialog), Type: 'body', Style: { width: '100px', minWidth: '100px', textAlign: 'right' } },
            { Id: 'delete', BodyTemplate: (rowData) => deleteTemplate(rowData, deleteRow), Type: 'body', Style: { width: '40px', minWidth: '40px', textAlign: 'left' } }
        ]
    };

    return (
        <div>
            <CustomBreadCrumb navItems={navItems} className="" />
            {/* //////////// ADD / EDIT DIALOG FORM ////////////// */}
            <TBFormDialog formDialogConfig={FormDialogConfig} />
            {/* //////////// ALERT DIALOG  ////////////// */}
            <TBAlertDialog alertDialogConfig={AlertDialogConfig} />
            {/* //////////// COUNTRIES DATA TABLEs  ////////////// */}
            <TBDataTable dataTableConfig={DataTableConfig} />
        </div>
    );
}

export default Countries;
