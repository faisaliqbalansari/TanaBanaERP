'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { useToast } from '@/layout/context/toastcontext';

import CustomBreadCrumb from '@/app/(main)/tanabana/common/components/BreadCrumb';
import TBFormDialog from '@/app/(main)/tanabana/common/components/tanabana-form-dialog';
import TBAlertDialog from '@/app/(main)/tanabana/common/components/tanabana-alert-dialog';
import TBDataTable from '@/app/(main)/tanabana/common/components/tanabana-data-table';
import { editTemplate, deleteTemplate, headerTemplate, filterData } from '@/app/(main)/tanabana/common/components/tanabana-data-table/tableTemplates';
//import { mockProvinces, mockCountries } from '@/app/(main)/tanabana/common/utility/mockData';
import { ProvinceService } from '@/app/(main)/tanabana/services/administration/master-setup/provinces/ProvinceService';

function Provinces() {
  const service = new ProvinceService();
  const [countries, setCountries] = useState([]);
  const [provinces, setProvinces] = useState([]);
  const [selectedProvince, setSelectedProvince] = useState(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [showNewProvinceDialog, setShowNewProvinceDialog] = useState(false);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const { success, error, warn } = useToast();
  const navItems = [
    { label: 'Administration' },
    { label: 'ERP Master Setup' },
    {
      label: 'Provinces',
        template: () => (
            <Link href="/tanabana/modules/administration/master-setup/provinces">
                <p className="">Provinces</p>
            </Link>
        )
    }
  ];

  ////////////////////////////////////// OPEN / CLOSE DIALOG HANDLERS //////////////////////////////////
  const DialogConfig = {
    dialog: showNewProvinceDialog,
    setDialog: setShowNewProvinceDialog
  };

  ////////////////////////////////////// OPEN / CLOSE ALERT DIALOG HANDLERS //////////////////////////////////
  const ConfirmationDialogConfig = {
    dialog: deleteConfirmation,
    setDialog: setDeleteConfirmation
  };

  ////////////////////////////////////// SELECT / UNSELECT TABLE DATA HANDLERS //////////////////////////////////
  const TableSelectedData = {
    selectedData: selectedProvince,
    setSelectedData: setSelectedProvince
  };

  ////////////////////////////////////// ADD / EDIT FORM FIELDS DATA //////////////////////////////////
  const Fields = [
    {
      Id: 'newProvinceCode',
      Label: 'Code',
      FieldType: 'string',
      IsRequired: true,
      Class: ''
    },
    {
      Id: 'newProvinceName',
      Label: 'Name',
      FieldType: 'text',
      IsRequired: true,
      Class: ''
    },
    {
      Id: 'newProvinceDescription',
      Label: 'Description',
      FieldType: 'text',
      IsRequired: true,
      Class: ''
    },
    {
      Id: 'newProvinceCountry',
      Label: 'Country',
      FieldType: 'select',
      IsRequired: true,
        DropdownData: countries.map(country => ({
            Id: country.id,
            name: country.name
        })),
      Class: ''
    }
  ];

  ////////////////////////////////////// ADD / EDIT FORM CONTROLLER //////////////////////////////////
  const {
    control,
    handleSubmit,
    reset,
    formState: { errors }
  } = useForm({
    defaultValues: {
      newProvinceCode: '',
      newProvinceName: '',
      newProvinceDescription: '',
      newProvinceCountry: null
    }
  });
  ////////////////////////////////////// FETCHING COUNTRIES DATA //////////////////////////////////

  const loadData = async () => {
    try {
      const [countriesData, provincesData] = await Promise.all([
        service.getCountries(),
        service.getProvinces()
      ]);

        setCountries(countriesData);
        setProvinces(provincesData);
      /*

      setDropdownCountries(countriesData);

      const provincesWithCountryNames = provincesData.map(province => ({
        ...province,
        countryName: countriesData.find(country => country.id === province.countryId)?.name || 'Unknown'
      }));
      setProvinces(provincesWithCountryNames);
        
        const provincesWithCountryNames = mockProvinces.map(province => ({
            ...province,
            countryName: mockCountries.find(country => country.id === province.countryId)?.name || 'Unknown'
        }));
        setCountries(mockCountries);
        setProvinces(provincesWithCountryNames);
        */
    } catch (e) {
        error('Error fetching data:', e);
    }
  };

  useEffect(() => {
      setLoading(true);
      loadData();
      setLoading(false);
      // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

    const fields = ['code', 'name', 'description'];
    const filteredData = filterData(provinces, searchQuery, fields);

      const openEditDialog = (province) => {
        reset({
          newProvinceCode: province.code,
          newProvinceName: province.name,
          newProvinceDescription: province.description,
          newProvinceCountry: province.countryId
        });

        setSelectedRowData(province);
        setShowNewProvinceDialog(true);
      };

      const openAddDialog = () => {
        // Reset form values for adding new city
        reset({
            newProvinceCode: '',
            newProvinceName: '',
            newProvinceDescription: '',
            newProvinceCountry: null
        });

        setSelectedRowData(null);
        setShowNewProvinceDialog(true);
    };
  const onRowEditComplete = (e) => {
    let updatedProvinces = [...provinces];
    updatedProvinces[e.index] = e.data;

    if (!e.newData.code || !e.newData.name) {
      error('Province', 'Fileds cant be empty');
    } else {
        service.saveProvince(e.newData).then(() => {
            loadData();
        });
    }
  };
  const onSubmit = async (data) => {
    if (!data.newProvinceCountry || !data.newProvinceName || !data.newProvinceCode || !data.newProvinceDescription) {
      error('Province', 'All fileds are required');
      return;
    }

    const provinceData = {
      code: data.newProvinceCode,
      name: data.newProvinceName,
      description: data.newProvinceDescription,
      countryId: data.newProvinceCountry.Id
    };

    try {
      if (selectedRowData) {
        provinceData.id = selectedRowData.id;
        await service.saveProvince(provinceData);
        success('Province', 'Record updated successfully');
      } else {
        provinceData.id = 0;
        await service.saveProvince(provinceData);
        success('Province', 'Record added successfully');
      }

      loadData();
      setShowNewProvinceDialog(false);
      reset();
    } catch (e) {
      error('Province', 'Error saving province');
    }
  };

  const deleteRow = (rowData) => {
      setDeleteConfirmation(true);
      setSelectedRowData(rowData);
  };

  const confirmDelete = () => {
    if (selectedRowData) {
        service
            .deleteProvince(selectedRowData.id) // Ensure ID is used
        .then(() => {
          success('Province', 'Record deleted successfully');

          loadData();
        })
        .catch((e) => {
          error('Province', 'Error in deleting record');
        });
    }
  };
    ////////////////////////////////////// TABLE HEADER CONFIG //////////////////////////////////
    const TableHeaderConfig = {
        TableName: 'Provinces',
        OpenDialog: openAddDialog,
        Searchable: true,
        SearchQuery: searchQuery,
        SetSearchQuery: setSearchQuery
    };
    ////////////////////////////////////// ADD / EDIT DIALOG FORM CONFIGRATION OBJET //////////////////////////////////
  const FormDialogConfig = {
    Id: '',
    FormFields: Fields,
    ImageGallary: null,
    OnSubmit: onSubmit,
    OnCancel: null,
    Class: '',
    Height:'385px',
    Width:'600px',
    DialogConfig: DialogConfig,
    ModelName: selectedRowData ? 'Edit State/Province' : 'Add New State/Province',
    FormHandler: { control, handleSubmit, reset, errors },
    ModelPosition: 'center',
    OnSubmitButtonText: selectedRowData ? 'Save' : 'Add',
      OnCanceltButtonText: 'Cancle',
      Height: '80vh',
      Width: '80vw'
};
////////////////////////////////////// ALERT DIALOG CONFIGRATION OBJET //////////////////////////////////
const AlertDialogConfig = {
    Id: '',
    ConfirmationDialogConfig: ConfirmationDialogConfig,
    Message: 'Are you sure you want to delete this province?',
    HeaderText: 'Confirmation',
    Icon: 'pi pi-exclamation-triangle',
    ConfirmButtonClass: 'p-button-secondary',
    ConfirmIcon: 'pi pi-trash',
    ConfirmButtonLabel: 'Yes',
    RejectButtonClass: 'p-button-secondary',
    RejectButtonLabel: 'No',
    OnConfirm: confirmDelete,
    OnReject: null
};
////////////////////////////////////// COUNTRIES DATA TABLE CONFIGRATION OBJET //////////////////////////////////
const DataTableConfig = {
    SelectedData: TableSelectedData,
    HeaderTemplate: (option) => headerTemplate(option, TableHeaderConfig),
    DataArray: filteredData,
    OnRowEditComplete: onRowEditComplete,
    loading:loading,
    Columns: [
        { Id: 'code', Field: 'code', Header: 'Code', Type: 'field', Style: { width: 'calc(20% - 175px)', minWidth: '', textAlign: 'left' } },
        { Id: 'name', Field: 'name', Header: 'Name', Type: 'field', Style: { width: 'calc(35% - 175px)', minWidth: '', textAlign: 'left' } },
        { Id: 'description', Field: 'description', Header: 'Description', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
        { Id: 'countryNmae', Field: 'countryName', Header: 'Country Name', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
        { Id: 'edit', BodyTemplate: (rowData) => editTemplate(rowData, openEditDialog), Type: 'body', Style: { width: '100px', minWidth: '100px', textAlign: 'right' } },
        { Id: 'delete', BodyTemplate: (rowData) => deleteTemplate(rowData, deleteRow), Type: 'body', Style: { width: '40px', minWidth: '40px', textAlign: 'left' } }
    ]
};

  return (
      <div>
          {/* //////////// BREADCRUMBS ////////////// */}
          <CustomBreadCrumb navItems={navItems} className="" />
            {/* //////////// ADD / EDIT DIALOG FORM ////////////// */} 
            <TBFormDialog formDialogConfig={FormDialogConfig} />
            {/* //////////// ALERT DIALOG  ////////////// */}
            <TBAlertDialog alertDialogConfig={AlertDialogConfig} />
            {/* //////////// COUNTRIES DATA TABLEs  ////////////// */}
            <TBDataTable dataTableConfig={DataTableConfig} />
  </div>
  );
}

export default Provinces;
