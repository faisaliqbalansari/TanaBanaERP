'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import CustomBreadCrumb from '@/app/(main)/tanabana/common/components/BreadCrumb';
import { CitiesService } from '@/app/(main)/tanabana/services/administration/master-setup/cities/CitiesService';
import { useToast } from '@/layout/context/toastcontext';
import { editTemplate, deleteTemplate, headerTemplate, filterData } from '@/app/(main)/tanabana/common/components/tanabana-data-table/tableTemplates';
import TBDataTable from '@/app/(main)/tanabana/common/components/tanabana-data-table';
import TBAlertDialog from '@/app/(main)/tanabana/common/components/tanabana-alert-dialog';
import TBFormDialog from '@/app/(main)/tanabana/common/components/tanabana-form-dialog';
// import { mockCities, mockCountries, mockProvinces } from '@/app/(main)/tanabana/common/utility/mockData';

function Cities() {
  const [countries, setCountries] = useState([]);
  const [provinces, setProvinces] = useState([]);
  const [cities, setCities] = useState([]);
  const [selectedCity, setSelectedCity] = useState(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [showNewCityDialog, setShowNewCityDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);

  const service = new CitiesService();
  const { success, error, warn } = useToast();

    ////////////////////////////////////// BREADCRUMS CONFIG //////////////////////////////////
  const navItems = [
    { label: 'Administration' },
    { label: 'ERP Master Setup' },
    {
      label: 'Cities',
        template: () => (
            <Link href="/tanabana/modules/administration/master-setup/cities">
                <p className="">Cities</p>
            </Link>
        )
    }
  ];

  ////////////////////////////////////// FETCH CITY's DATA //////////////////////////////////
  const loadData = async () => {
    try {
      const [countriesData, provincesData, citiesData] = await Promise.all([
        service.getCountries(),
        service.getProvinces(),
        service.getCities()
      ]);

      setCountries(countriesData);
      //setDropdownCountries(countriesData);

      setProvinces(provincesData);
      setCities(citiesData);
      //setDropdownProvinces(provincesData);

       /*
       const citiesWithProvinceAndCountryNames = citiesData.map(city => ({
            ...city,
            countryName: countriesData.find(country => country.id === city.countryId)?.name || 'Unknown',
            provinceName: provincesData.find(province => province.id === city.provinceId)?.name || 'Unknown'
        }));

        setCities(citiesWithProvinceAndCountryNames);
        
              const citiesWithProvinceAndCountryNames = mockCities.map((city) => ({
                  ...city,
                  countryName: mockCountries.find((country) => country.id === city.countryId)?.name || 'Unknown',
                  provinceName: mockProvinces.find((province) => province.id === city.provinceId)?.name || 'Unknown'
              }));
              setCountries(mockCountries);
  
              setProvinces(mockProvinces);
              setCities(citiesWithProvinceAndCountryNames);
              */
    } catch (e) {
        error('City', 'Could Not Get Citiies');
    }
  };

  useEffect(() => {
      setLoading(true);
      loadData();
      setLoading(false);
            // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

    ////////////////////////////////////// FILTER HANDLER //////////////////////////////////
    const fields = ['code', 'name', 'description', 'countryName', 'provinceName'];
    const filteredData = filterData(cities, searchQuery, fields);

    ////////////////////////////////////// DATA TABLE TEMPLATES //////////////////////////////////
  const openEditDialog = (city) => {
    reset({
      newCityCode: city.code,
      newCityName: city.name,
      newCityDescription: city.description,
      newCityCountry: city.countryId,
      newCityProvince: city.provinceId
    });

    setSelectedRowData(city);
    setShowNewCityDialog(true);
  };

    const openAddDialog = () => {
      // Reset form values for adding new city
    reset({
      newCityCode: '',
      newCityName: '',
      newCityDescription: '',
      newCityCountry: null,
      newCityProvince: null
    });

    setSelectedRowData(null);
    setShowNewCityDialog(true);
  };
  const onRowEditComplete = async (e) => {
    if (!e.newData.code || !e.newData.name || !e.newData.description) {
      error('City', 'Fields can\'t be empty');
      return;
    }

    try {
      await service.saveCity(e.newData);
      success('City', 'Record saved successfully');
    } catch (e) {
      error('City', 'Error saving record');
    }
    loadData();
  };

    const deleteRow = (rowData) => {
        setDeleteConfirmation(true);
        setSelectedRowData(rowData);
    };

    ////////////////////////////////////// FORM HANDLERS //////////////////////////////////
    const {
        control,
        handleSubmit,
        reset,
        watch,
        formState: { errors }
    } = useForm({
        defaultValues: {
            newCityCode: '',
            newCityName: '',
            newCityDescription: '',
            newCityCountry: null,
            newCityProvince: null
        }
    });

    // Watching parent field values
    const selectedCountry = watch('newCityCountry'); // Watching country selection

    // Filtering provinces based on selected country
    const filteredProvinces = selectedCountry ? provinces.filter((province) => province.countryId === selectedCountry) : [];

    ////////////////////////////////////// ON EDIT / ADD CITY  /////////////////////////////////
  const onSubmit = async (data) => {
    if (!data.newCityCountry || !data.newCityProvince || !data.newCityName || !data.newCityCode || !data.newCityDescription) {
      error('City', 'Fields can\'t be empty');
      return;
    }

    const cityData = {
      code: data.newCityCode,
      name: data.newCityName,
      description: data.newCityDescription,
      countryId: data.newCityCountry.id,
      provinceId: data.newCityProvince.id
    };

    try {
      if (selectedRowData) {
        cityData.id = selectedRowData.id;
        await service.saveCity(cityData);
        success('City', 'City updated successfully');
      } else {
        cityData.id = 0; // Ensuring this is set for new cities
        await service.saveCity(cityData);
        success('City', 'City added successfully');
      }
  
      loadData();
      setShowNewCityDialog(false);
      reset();
    } catch (e) {
      error('City', 'Error saving record');
    }
  };

      ////////////////////////////////////// ON CITY DELETE //////////////////////////////////
  const confirmDelete = async () => {
    if (selectedRowData) {
      try {
        await service.deleteCity(selectedRowData.id);
        success('City', 'Deleted successfully');
        loadData();
      } catch (e) {
        error('City', 'Error in deleting city');
      }
    }
    setDeleteConfirmation(false);
  };
    ////////////////////////////////////// OPEN / CLOSE DIALOG HANDLERS //////////////////////////////////
    const DialogConfig = {
        dialog: showNewCityDialog,
        setDialog: setShowNewCityDialog
    };

    ////////////////////////////////////// OPEN / CLOSE ALERT DIALOG HANDLERS //////////////////////////////////
    const ConfirmationDialogConfig = {
        dialog: deleteConfirmation,
        setDialog: setDeleteConfirmation
    };

    ////////////////////////////////////// SELECT / UNSELECT TABLE DATA HANDLERS //////////////////////////////////
    const TableSelectedData = {
        selectedData: selectedCity,
        setSelectedData: setSelectedCity
    };
  const cancelDelete = () => {
    setDeleteConfirmation(false);
    setSelectedRowData(null);
  };

  const onCountryChange = async (e) => {
    
    const selectedCountry = e.value;
    setSelectedCountry(selectedCountry);
    const ProvinceList = await service.getProvinces(selectedCountry.id);
    setDropdownProvinces(ProvinceList);
  };

  const onProvinceChange = (e) => {
     setSelectedProvince(e.value);
  };
    ////////////////////////////////////// ADD / EDIT FORM FIELDS DATA //////////////////////////////////
    const Fields = [
        {
            Id: 'newCityCode',
            Label: 'Code',
            FieldType: 'number',
            IsRequired: true,
            Class: ''
        },
        {
            Id: 'newCityName',
            Label: 'Name',
            FieldType: 'text',
            IsRequired: true,
            Class: '',
            AdditionalRules: { pattern: { value: /^[a-zA-Z\s'-]+$/, message: 'Numbers and symbols are not allowed' } }
        },
        {
            Id: 'newCityDescription',
            Label: 'Description',
            FieldType: 'text',
            IsRequired: true,
            Class: ''
        },
        {
            Id: 'newCityCountry',
            Label: 'Country',
            FieldType: 'select',
            IsRequired: true,
            DropdownData: countries.map((country) => ({
                Id: country.id,
                name: country.name
            })),
            Class: ''
        },
        {
            Id: 'newCityProvince',
            Label: 'Province',
            FieldType: 'select',
            IsRequired: true,
            DropdownData: filteredProvinces.map((province) => ({
                Id: province.id,
                name: province.name
            })),
            Class: ''
        }
    ];
    ////////////////////////////////////// TABLE HEADER CONFIG //////////////////////////////////
    const TableHeaderConfig = {
        TableName: 'Cities',
        OpenDialog: openAddDialog,
        Searchable: true,
        SearchQuery: searchQuery,
        SetSearchQuery: setSearchQuery
    };
    ////////////////////////////////////// ADD / EDIT DIALOG FORM CONFIGRATION OBJET //////////////////////////////////
    const FormDialogConfig = {
        Id: '',
        FormFields: Fields,
        ImageGallary: null,
        OnSubmit: onSubmit,
        OnCancel: null,
        Class: '',
        DialogConfig: DialogConfig,
        ModelName: selectedRowData ? 'Edit City' : 'Add New City',
        FormHandler: { control, handleSubmit, reset, errors },
        ModelPosition: 'center',
        OnSubmitButtonText: selectedRowData ? 'Save' : 'Add',
        OnCanceltButtonText: 'Cancle',
        Height: '80vh',
        Width: '80vw'
    };
    ////////////////////////////////////// ALERT DIALOG CONFIGRATION OBJET //////////////////////////////////
    const AlertDialogConfig = {
        Id: '',
        ConfirmationDialogConfig: ConfirmationDialogConfig,
        Message: 'Are you sure you want to delete this city?',
        HeaderText: 'Confirmation',
        Icon: 'pi pi-exclamation-triangle',
        ConfirmButtonClass: 'p-button-secondary',
        ConfirmIcon: 'pi pi-trash',
        ConfirmButtonLabel: 'Yes',
        RejectButtonClass: 'p-button-secondary',
        RejectButtonLabel: 'No',
        OnConfirm: confirmDelete,
        OnReject: null
    };
    ////////////////////////////////////// COUNTRIES DATA TABLE CONFIGRATION OBJET //////////////////////////////////
    const DataTableConfig = {
        SelectedData: TableSelectedData,
        HeaderTemplate: (option) => headerTemplate(option, TableHeaderConfig),
        DataArray: filteredData,
        OnRowEditComplete: onRowEditComplete,
        loading: loading,
        Columns: [
            { Id: 'code', Field: 'code', Header: 'Code', Type: 'field', Style: { width: 'calc(20% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'name', Field: 'name', Header: 'Name', Type: 'field', Style: { width: 'calc(35% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'description', Field: 'description', Header: 'Description', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'provinceName', Field: 'provinceName', Header: 'Province Name', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'countryName', Field: 'countryName', Header: 'Country Name', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'edit', BodyTemplate: (rowData) => editTemplate(rowData, openEditDialog), Type: 'body', Style: { width: '100px', minWidth: '100px', textAlign: 'right' } },
            { Id: 'delete', BodyTemplate: (rowData) => deleteTemplate(rowData, deleteRow), Type: 'body', Style: { width: '40px', minWidth: '40px', textAlign: 'left' } }
        ]
    };

  return (
    <div>
      <CustomBreadCrumb navItems={navItems} className="" />

          {/* //////////// ADD / EDIT DIALOG FORM ////////////// */}
          <TBFormDialog formDialogConfig={FormDialogConfig} />
          {/* //////////// ALERT DIALOG  ////////////// */}
          <TBAlertDialog alertDialogConfig={AlertDialogConfig} />
          {/* //////////// COUNTRIES DATA TABLEs  ////////////// */}
          <TBDataTable dataTableConfig={DataTableConfig} />
    </div>
  );
}

export default Cities;
