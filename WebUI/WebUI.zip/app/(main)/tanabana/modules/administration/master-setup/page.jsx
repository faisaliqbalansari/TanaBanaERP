export default function Page() {
  return <h1>Hello, Tana Bana administration - master setup page!</h1>
}