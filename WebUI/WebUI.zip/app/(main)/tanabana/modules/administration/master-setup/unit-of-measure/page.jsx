'use client';
import React, { useState, useEffect } from 'react';
import Link from "next/link";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';
import { InputText } from 'primereact/inputtext';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { useForm, Controller } from 'react-hook-form';
import { useToast } from '@/layout/context/toastcontext';
import { useConfirmDialog } from '@/layout/context/confirmdialogcontext'; 
import { UnitOfMeasureService } from '@/app/(main)/tanabana/services/administration/master-setup/unit-of-measure/UnitOfMeasureService.tsx';

import CustomBreadCrumb from "@/app/(main)/tanabana/common/components/BreadCrumb";

function UnitOfMeasure() {
  const [units, setUnits] = useState([]);
  const [selectedUnitOfMeasure, setSelectedUnitOfMeasure] = useState(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState('add'); // 'add' or 'edit'
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const service = new UnitOfMeasureService();
  const { success, error, warn } = useToast();
  const {show} = useConfirmDialog();

  const navItems = [
    { label: 'Administration' },
    { label: 'ERP Master Setup' },
    {
      label: 'Units of Measure',
      template: () => <Link href="/tanabana/modules/administration/master-setup/unit-of-measure"><p className="">Units of Measure</p></Link>
    }
  ];

  const { control, handleSubmit, reset, formState: { errors } } = useForm({
    defaultValues: {
      newUnitOfMeasureCode: '',
      newUnitOfMeasureName: '',
      newUnitOfMeasureDescription: '',
      disabled: false
    }
  });

  useEffect(() => {
    loadUnitOfMeasure();
  }, []);
  
  const loadUnitOfMeasure = () => {
    service.getUnitOfMeasures()
      .then((unitsData) => {
        setUnits(unitsData);
      })
      .catch(() => {
        error('Unit of Measure', 'Error loading units of measure');
      });
  };
  

  const filteredUnitOfMeasure = units.filter(unit =>
    unit.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    unit.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    unit.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const openEditDialog = (unit) => {
    reset({
      newUnitOfMeasureCode: unit.code,
      newUnitOfMeasureName: unit.name,
      newUnitOfMeasureDescription: unit.description,
    });

    setSelectedRowData(unit);
    setDialogMode('edit');
    setShowDialog(true);
  };

  const openAddDialog = () => {
    reset({
      newUnitOfMeasureCode: '',
      newUnitOfMeasureName: '',
      newUnitOfMeasureDescription: '',
    });

    setSelectedRowData(null);
    setDialogMode('add');
    setShowDialog(true);
  };

  const onSubmit = async (data) => {
    if (!data.newUnitOfMeasureCode || !data.newUnitOfMeasureName) {
      error('Unit of Measure', 'All fields are required');
      return;
    }

    const unitOfMeasureData = {
      code: data.newUnitOfMeasureCode,
      name: data.newUnitOfMeasureName,
      description: data.newUnitOfMeasureDescription,
    };

    try {
      if (selectedRowData) {
        unitOfMeasureData.id = selectedRowData.id;
        await service.saveUnitOfMeasure(unitOfMeasureData);
        success('Unit of Measure', 'Unit of Measure updated successfully');
      } else {
        unitOfMeasureData.id = 0;
        await service.saveUnitOfMeasure(unitOfMeasureData);
        success('Unit of Measure', 'Unit of Measure added successfully');
      }
      loadUnitOfMeasure();
      setShowDialog(false);
      reset();
    } catch (error) {
      error('Unit of Measure', 'Error saving Unit of Measure');
    }
  };

  const textEditor = (options) => {
    return <InputText type="text" value={options.value} onChange={(e) => options.editorCallback(e.target.value)} />;
  };

  const deleteRow = (rowData) => {
    show(
      'Are you sure you want to delete this unit?',
      () => {
        service.deleteUnitOfMeasure(rowData.id)
          .then(() => {
            success('Unit of measurement', 'unit deleted successfully');
            loadUnitOfMeasure();
          })
          .catch(() => {
            warn('Unit of measurement', 'unit cannot be deleted');
          });
      },
      () => {}
    );
  };
  const confirmDelete = () => {
    if (selectedRowData) {
      service.deleteUnitOfMeasure(selectedRowData.id)
        .then(() => {
          success("Unit of Measure", "Unit of Measure deleted successfully");
          loadUnitOfMeasure();
        })
        .catch(() => {
          warn('Unit of Measure', 'Unit of Measure cannot be deleted');
        });
    }
    setDeleteConfirmation(false);
  };

  const cancelDelete = () => {
    setDeleteConfirmation(false);
    setSelectedRowData(null);
  };

  const headerTemplate = (options) => {
    const className = `${options.className} justify-content-space-between`;

    return (
      <div className={className}>
        <div className="flex align-items-center gap-2">
          <span className="font-bold">Units of Measure</span>
        </div>
        <div className='text-right'>
          <InputText
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search..."
            className="ml-2 p-1 mr-3"
          />
          <Button className="p-2 mr-3 p-button-secondary" label="Add New" onClick={openAddDialog} />
          {options.togglerElement}
        </div>
      </div>
    );
  };

  const deleteTemplate = (rowData) => {
    return (
      <span className="p-cursor-pointer" onClick={() => deleteRow(rowData)} style={{ cursor: 'pointer' }}>
        <i className="pi pi-trash" />
      </span>
    );
  };

  const editTemplate = (rowData) => {
    return (
      <span className="p-cursor-pointer" onClick={() => openEditDialog(rowData)} style={{ cursor: 'pointer' }}>
        <i className="pi pi-pencil" />
      </span>
    );
  };

  return (
    <div>
      <CustomBreadCrumb navItems={navItems} className="" />

      <Dialog
        visible={showDialog}
        style={{ width: '50vw' }}
        onHide={() => setShowDialog(false)}
        header={dialogMode === 'edit' ? "Edit Unit of Measure" : "Add New Unit of Measure"}
        position="center"
      >
        <form onSubmit={handleSubmit(onSubmit)} className="p-fluid mt-2">
          <div className="mb-2">
            <label htmlFor="newUnitOfMeasureCode" className='font-semibold'>Code:</label>
            <Controller
              name="newUnitOfMeasureCode"
              control={control}
              rules={{ required: 'Code is required' }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newUnitOfMeasureCode"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
            {errors.newUnitOfMeasureCode && <small className="p-error">{errors.newUnitOfMeasureCode?.message}</small>}
          </div>
          <div className="mb-2">
            <label htmlFor="newUnitOfMeasureName" className='font-semibold'>Name:</label>
            <Controller
              name="newUnitOfMeasureName"
              control={control}
              rules={{ required: 'Name is required' }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newUnitOfMeasureName"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
            {errors.newUnitOfMeasureName && <small className="p-error">{errors.newUnitOfMeasureName?.message}</small>}
          </div>
          <div className="mb-2">
            <label htmlFor="newUnitOfMeasureDescription" className='font-semibold'>Description:</label>
            <Controller
              name="newUnitOfMeasureDescription"
              control={control}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id="newUnitOfMeasureDescription"
                  className='mt-1 mb-0 p-2'
                  value={value}
                  onChange={onChange}
                />
              )}
            />
          </div>
          <div className="p-mt-3 p-d-flex p-jc-end text-right">
            <Button type="submit" label="Save" icon="pi pi-check" className="p-button-secondary mt-3 col-3 mr-1" />
            <Button label="Cancel" icon="pi pi-times" className="p-button-secondary p-ml-2 mt-3 col-3" outlined onClick={() => setShowDialog(false)} />
          </div>
        </form>
      </Dialog>

      <div className='pt-3 p-3'>
      <Panel headerTemplate={headerTemplate} >
          <div className="p-2 rounded-corner">
            <DataTable value={filteredUnitOfMeasure}
              scrollable
              scrollHeight="calc(100vh - 200px)"
              editMode="row"
              selection={selectedUnitOfMeasure}
              onSelectionChange={(e) => setSelectedUnitOfMeasure(e.value)}
              dataKey="id"
              tableStyle={{ minWidth: 'calc(100% - 300px)' }}
              >
              <Column field="code" header="Code" editor={(options) => textEditor(options)} style={{ width: 'calc(20% - 175px)' }}></Column>
              <Column field="name" header="Name" editor={(options) => textEditor(options)} style={{ width: 'calc(35% - 175px)' }}></Column>
              <Column field="description" header="Description" editor={(options) => textEditor(options)} style={{ width: 'calc(45% - 175px)' }}></Column>
              <Column body={editTemplate} headerStyle={{ width: '100px', minWidth: '100px' }} bodyStyle={{ textAlign: 'right' }}></Column>
              <Column body={deleteTemplate} headerStyle={{ width: '40px', minWidth: '40px' }} bodyStyle={{ textAlign: 'left' }}></Column>
            </DataTable>
          </div>
        </Panel>
      </div>

      <ConfirmDialog
        visible={deleteConfirmation}
        onHide={() => setDeleteConfirmation(false)}
        message="Are you sure you want to delete this unit of measure?"
        header="Confirmation"
        icon="pi pi-exclamation-triangle"
        accept={confirmDelete}
        reject={cancelDelete}
      />
    </div>
  );
}

export default UnitOfMeasure;
