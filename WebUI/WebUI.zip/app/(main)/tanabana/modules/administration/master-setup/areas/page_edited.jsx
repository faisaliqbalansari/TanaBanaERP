'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import CustomBreadCrumb from '@/app/(main)/tanabana/common/components/BreadCrumb';
import { AreaService } from '@/app/(main)/tanabana/services/administration/master-setup/areas/AreaService';
import { useToast } from '@/layout/context/toastcontext';
import { useConfirmDialog } from '@/layout/context/confirmdialogcontext';

import { editTemplate, deleteTemplate, headerTemplate, filterData } from '@/app/(main)/tanabana/common/components/tanabana-data-table/tableTemplates';
import TBDataTable from '@/app/(main)/tanabana/common/components/tanabana-data-table';
import TBAlertDialog from '@/app/(main)/tanabana/common/components/tanabana-alert-dialog';
import TBFormDialog from '@/app/(main)/tanabana/common/components/tanabana-form-dialog';
function AreasPage() {
  const service = new AreaService();
  const [countries, setCountries] = useState([]);
  const [provinces, setProvinces] = useState([]);
  const [cities, setCities] = useState([]);
  const [areas, setAreas] = useState([]);
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [selectedProvince, setSelectedProvince] = useState(null);
  const [selectedCity, setSelectedCity] = useState(null);
  const [selectedArea, setSelectedArea] = useState(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState(false);
  const [selectedRowData, setSelectedRowData] = useState(null);
  const [showNewAreaDialog, setShowNewAreaDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

    const {
        control,
        handleSubmit,
        reset,
        formState: { errors }
    } = useForm({
    defaultValues: {
      newAreaCode: '',
      newAreaName: '',
      newAreaDescription: '',
      newAreaCountry: null,
      newAreaProvince: null,
      newAreaCity: null
    }
  });

  const { success, error, warn } = useToast();
  const {show} = useConfirmDialog();

  const [dropdownCountries, setDropdownCountries] = useState([]);
  const [dropdownProvinces, setDropdownProvinces] = useState([]);
  const [dropdownCities, setDropdownCities] = useState([]);

  const navItems = [
    { label: 'Administration' },
    { label: 'ERP Master Setup' },
    {
      label: 'Areas',
        template: () => (
            <Link href="/tanabana/modules/administration/master-setup/areas">
                <p className="">Areas</p>
            </Link>
        )
    }
  ];

  const loadData = async () => {
    try {
      const [countriesData, provincesData, citiesData, areasData] = await Promise.all([
        service.getCountries(),
        service.getProvinces(),
        service.getCities(),
        service.getCityAreas()
      ]);
      
      setCountries(countriesData);
      setDropdownCountries(countriesData); 
      
      setProvinces(provincesData);
      setDropdownProvinces(provincesData);

      setCities(citiesData);
      setDropdownCities(citiesData);

        const areasWithDetails = areasData.map((area) => ({
            ...area,
            countryName: countriesData.find((country) => country.id === area.countryId)?.name || 'Unknown',
            provinceName: provincesData.find((province) => province.id === area.provinceId)?.name || 'Unknown',
            cityName: citiesData.find((city) => city.id === area.cityId)?.name || 'Unknown'
      }));

        setAreas(areasWithDetails);
        /*
             setCountries(mockCountries);
 
             setProvinces(mockProvinces);
 
             setCities(mockCities);
 
             const areasWithDetails = mockAreas.map((area) => {
               return({
                 ...area,
                 countryName: mockCountries.find((country) => country.id === area.countryId)?.name || 'Unknown',
                 provinceName: mockProvinces.find((province) => province.id === area.provinceId)?.name || 'Unknown',
                 cityName: mockCities.find((city) => city.id === area.cityId)?.name || 'Unknown'
             })});
 
             setAreas(areasWithDetails);
             */
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  useEffect(() => {
      loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

    ////////////////////////////////////// FILTER HANDLER //////////////////////////////////
    const fields = ['code', 'name', 'description', 'cityName', 'countryName', 'provinceName'];
    const filteredData = filterData(areas, searchQuery, fields);
    /*
    const filteredAreas = areas.filter(area =>
    area.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
    area.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    area.description.toLowerCase().includes(searchQuery.toLowerCase())
    );*/

  const openEditDialog = (area) => {
    reset({
      newAreaCode: area.code,
      newAreaName: area.name,
      newAreaDescription: area.description,
      newAreaCountry: area.countryId,
      newAreaProvince: area.provinceId,
      newAreaCity: area.cityId
    });

    setSelectedRowData(area);
    setSelectedCountry(countries.find(country => country.id === area.countryId));
    setSelectedProvince(provinces.find(province => province.id === area.provinceId));
    setSelectedCity(cities.find(city => city.id === area.cityId));
    setShowNewAreaDialog(true);
  };

  const openNewAreaDialog = () => {
    reset({
      newAreaCode: '',
      newAreaName: '',
      newAreaDescription: '',
      newAreaCountry: null,
      newAreaProvince: null,
      newAreaCity: null
    });

    setSelectedRowData(null);
    setSelectedCountry(null);
    setSelectedProvince(null);
    setSelectedCity(null);
    setShowNewAreaDialog(true);
  };

  const onRowEditComplete = (e) => {
    let updatedAreas = [...areas];
    updatedAreas[e.index] = e.data;

    if (!e.newData.code || !e.newData.name) {
      error('Area', 'All fields are required');
    } else {
        service
            .saveCityArea(e.newData)
            .then(() => {
               success('Area', 'Record saved successfully');
                loadData();
            })
            .catch((error) => {
                console.error('Error saving record:', error);
            });
    }
  };

  const onSubmit = async (data) => {
    if (!data.newAreaCountry || !data.newAreaProvince || !data.newAreaCity || !data.newAreaName || !data.newAreaCode || !data.newAreaDescription) {
      alert('All fields are required');
      return;
    }

    const areaData = {
      code: data.newAreaCode,
      name: data.newAreaName,
      description: data.newAreaDescription,
      countryId: data.newAreaCountry.id,
      provinceId: data.newAreaProvince.id,
      cityId: data.newAreaCity.id
    };

    try {
      if (selectedRowData) {
        areaData.id = selectedRowData.id;
        await service.saveCityArea(areaData);
         success('Area', 'Area updated successfully');
      } else {
        areaData.id = 0;
        await service.saveCityArea(areaData);
        success('Area', 'Area added successfully');
      }
      
      loadData();
      setShowNewAreaDialog(false);
      reset();
    } catch (error) {
      error('Error saving area:', error);
    }
  };

  const deleteRow = (rowData) => {
      setSelectedRowData(rowData);
      setDeleteConfirmation(true);
  };
  const confirmDelete = async () => {
    if (selectedRowData) {
      try {
        await service.deleteCityArea(selectedRowData.id);
        success('Area', 'Area deleted successfully');
        loadData();
      } catch {
       warn('Area', 'Area can not be deleted');
      }
    }
  };

    ////////////////////////////////////// OPEN / CLOSE DIALOG HANDLERS //////////////////////////////////
    const DialogConfig = {
        dialog: showNewAreaDialog,
        setDialog: setShowNewAreaDialog
    };

    ////////////////////////////////////// OPEN / CLOSE ALERT DIALOG HANDLERS //////////////////////////////////
    const ConfirmationDialogConfig = {
        dialog: deleteConfirmation,
        setDialog: setDeleteConfirmation
    };

    ////////////////////////////////////// SELECT / UNSELECT TABLE DATA HANDLERS //////////////////////////////////
    const TableSelectedData = {
        selectedData: selectedArea,
        setSelectedData: setSelectedArea
    };
  const onCountryChange = async (e) => {
    setSelectedCountry(e.value);
    const countryId = e.value;
    const provinceList = await service.getProvinces(countryId);
    setDropdownProvinces(provinceList);
  };
  
  const onProvinceChange = async (e) => {
    setSelectedProvince(e.value);
    const provinceId = e.value
    const cityList = await service.getCities(provinceId);
    setDropdownCities(cityList);
  };
  
  const onCityChange = (e) => {
    setSelectedCity(e.value)
  };

    ////////////////////////////////////// ADD / EDIT FORM FIELDS DATA //////////////////////////////////
    const Fields = [
        {
            Id: 'newAreaCode',
            Label: 'Code',
            FieldType: 'number',
            IsRequired: true,
            Class: ''
        },
        {
            Id: 'newAreaName',
            Label: 'Name',
            FieldType: 'text',
            IsRequired: true,
            Class: '',
            AdditionalRules: { pattern: { value: /^[a-zA-Z\s'-]+$/, message: 'Numbers and symbols are not allowed' } }
        },
        {
            Id: 'newAreaDescription',
            Label: 'Description',
            FieldType: 'text',
            IsRequired: true,
            Class: ''
        },
        {
            Id: 'newAreaCountry',
            Label: 'Country',
            FieldType: 'select',
            IsRequired: true,
            DropdownData: countries,
            Class: ''
        },
        {
            Id: 'newAreaProvince',
            Label: 'Province',
            FieldType: 'select',
            IsRequired: true,
            DropdownData: provinces,
            Class: ''
        },
        {
            Id: 'newAreaCity',
            Label: 'Province',
            FieldType: 'select',
            IsRequired: true,
            DropdownData: cities,
            Class: ''
        }
    ];
    ////////////////////////////////////// TABLE HEADER CONFIG //////////////////////////////////
    const TableHeaderConfig = {
        TableName: 'Areas',
        OpenDialog: openNewAreaDialog,
        Searchable: true,
        SearchQuery: searchQuery,
        SetSearchQuery: setSearchQuery
    };
    ////////////////////////////////////// ADD / EDIT DIALOG FORM CONFIGRATION OBJET //////////////////////////////////
    const FormDialogConfig = {
        Id: '',
        FormFields: Fields,
        ImageGallary: null,
        OnSubmit: onSubmit,
        OnCancel: null,
        Class: '',
        DialogConfig: DialogConfig,
        ModelName: selectedRowData ? 'Edit Area' : 'Add New Area',
        FormHandler: { control, handleSubmit, reset, errors },
        ModelPosition: 'center',
        OnSubmitButtonText: selectedRowData ? 'Save' : 'Add',
        OnCanceltButtonText: 'Cancle',
        Height: '',
        Width: ''
    };
    ////////////////////////////////////// ALERT DIALOG CONFIGRATION OBJET //////////////////////////////////
    const AlertDialogConfig = {
        Id: '',
        ConfirmationDialogConfig: ConfirmationDialogConfig,
        Message: 'Are you sure you want to delete this area?',
        HeaderText: 'Confirmation',
        Icon: 'pi pi-exclamation-triangle',
        ConfirmButtonClass: 'p-button-secondary',
        ConfirmIcon: 'pi pi-trash',
        ConfirmButtonLabel: 'Yes',
        RejectButtonClass: 'p-button-secondary',
        RejectButtonLabel: 'No',
        OnConfirm: confirmDelete,
        OnReject: null
    };
    ////////////////////////////////////// COUNTRIES DATA TABLE CONFIGRATION OBJET //////////////////////////////////
    const DataTableConfig = {
        SelectedData: TableSelectedData,
        HeaderTemplate: (option) => headerTemplate(option, TableHeaderConfig),
        DataArray: filteredData,
        OnRowEditComplete: onRowEditComplete,
        Columns: [
            { Id: 'code', Field: 'code', Header: 'Code', Type: 'field', Style: { width: 'calc(20% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'name', Field: 'name', Header: 'Name', Type: 'field', Style: { width: 'calc(35% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'description', Field: 'description', Header: 'Description', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'cityName', Field: 'cityName', Header: 'City', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'provinceName', Field: 'provinceName', Header: 'Province', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'countryName', Field: 'countryName', Header: 'Country Name', Type: 'field', Style: { width: 'calc(45% - 175px)', minWidth: '', textAlign: 'left' } },
            { Id: 'edit', BodyTemplate: (rowData) => editTemplate(rowData, openEditDialog), Type: 'body', Style: { width: '100px', minWidth: '100px', textAlign: 'right' } },
            { Id: 'delete', BodyTemplate: (rowData) => deleteTemplate(rowData, deleteRow), Type: 'body', Style: { width: '40px', minWidth: '40px', textAlign: 'left' } }
        ]
    };

  return (
    <div>
      <CustomBreadCrumb navItems={navItems} className="" />

          {/* //////////// ADD / EDIT DIALOG FORM ////////////// */}
          <TBFormDialog formDialogConfig={FormDialogConfig} />
          {/* //////////// ALERT DIALOG  ////////////// */}
          <TBAlertDialog alertDialogConfig={AlertDialogConfig} />
          {/* //////////// COUNTRIES DATA TABLEs  ////////////// */}
          <TBDataTable dataTableConfig={DataTableConfig} />
    </div>
  );
}

export default AreasPage;
