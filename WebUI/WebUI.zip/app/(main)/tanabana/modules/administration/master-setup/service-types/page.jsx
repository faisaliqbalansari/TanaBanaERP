export default function Page() {
  return <h1>Hello, Tana Bana administration - service type setup page!</h1>
}