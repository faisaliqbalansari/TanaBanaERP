export default function Page() {
    return <h1>Hello, Tana Bana administration - service-providers setup page!</h1>
  }