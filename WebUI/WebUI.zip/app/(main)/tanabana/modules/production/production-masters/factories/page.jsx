export default function Page() {
    return <h1>Hello, Tana Bana administration - factories setup page!</h1>
  }