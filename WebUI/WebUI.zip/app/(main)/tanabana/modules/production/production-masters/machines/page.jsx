export default function Page() {
    return <h1>Hello, Tana Bana administration - machines setup page!</h1>
  }