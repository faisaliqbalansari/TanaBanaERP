export default function Page() {
    return <h1>Hello, Tana Bana administration - material-inventory setup page!</h1>
  }