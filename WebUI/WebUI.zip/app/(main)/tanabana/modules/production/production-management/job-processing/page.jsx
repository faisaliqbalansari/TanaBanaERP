export default function Page() {
    return <h1>Hello, Tana Bana administration - job-processing setup page!</h1>
  }