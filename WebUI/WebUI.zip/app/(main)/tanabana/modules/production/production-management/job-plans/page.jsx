export default function Page() {
    return <h1>Hello, Tana Bana administration - job-planes setup page!</h1>
  }