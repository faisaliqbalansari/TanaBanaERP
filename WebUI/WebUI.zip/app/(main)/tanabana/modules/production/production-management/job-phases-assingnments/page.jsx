export default function Page() {
    return <h1>Hello, Tana Bana administration - job-phases-assingnments setup page!</h1>
  }