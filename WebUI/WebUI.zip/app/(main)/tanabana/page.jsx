export default function Page() {
  return <h1>Hello, Tana Bana page!</h1>
}