

export interface DialogField {
    id: string;
    label: string;
    inputType: 'text' | 'textarea';
    required: boolean;
    hideFromUI: boolean;
    value?: string;
    onChange?: any;
  }
  
  export interface DialogComponentProps {
    showDialog: boolean;
    dialogMode: 'add' | 'edit' | null;
    formData: Record<string, any>; 
    dialogFields: DialogField[];
    closeDialog: () => void;
    onSubmit: (data: Record<string, any>) => void;
  }
  