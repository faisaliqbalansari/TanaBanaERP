import { NumericKeys } from "react-hook-form/dist/types/path/common";

export class DialogCrudModel {
 
    ShowDialog: boolean = false;
    Width: string = 'vw50';
    Height: string = 'vw50';
    Header: string = '';
    Position: string = 'center';
    StyleCSS: string = '';
    Fields: any [] =  [];

    OnHide: any = null;
    OnSubmit: any = null;
    OnCancell: any = null;

    constructor() {
      this.ShowDialog = false;
      this.Width = 'vw50';
      this.Height = 'vw50';
      this.Header = '';
      this.Position = 'center';
      this.StyleCSS = '';
      this.Fields =  [];
    }

    executeOnHide(): void {
      if(this.OnHide) {
        this.OnHide();
      }
    }

    executeOnSubmit(): void {
      if(this.OnSubmit) {
        this.OnSubmit();
      }
    }

    executeOnCancell(): void {
      if(this.OnCancell) {
        this.OnCancell();
      }
    }
    // Add more properties if needed
}

/*
export class DialogCrudFieldModel {
  Id: string = '';
  Label: string;
  InputType: InputType;
  Required: boolean;
  Value: string = '';

  constructor() {
    this.Label = '';
    this.InputType = InputType.TextField;
    this.Required = false;
  }

  // Add more properties if needed
}

  export enum InputType {
    TextField = 1,
    TextArea = 2,
    Dropdown = 3
  }
  */