import React from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Controller, useForm } from 'react-hook-form';
import { DialogComponentProps } from './DialogComponentTypes';

export const DialogComponent: React.FC<DialogComponentProps> = ({
  showDialog,
  dialogMode,
  formData,
  dialogFields,
  closeDialog,
  onSubmit
}) => {
  // Initialize default values for the form
  const defaultValues = dialogFields.reduce((acc, field) => ({
    ...acc,
    [field.id]: formData[field.id] || field.value || ''
  }), {} as Record<string, any>);

  // Set up the form with react-hook-form
  const { control, handleSubmit, formState: { errors } } = useForm({
    defaultValues
  });

  const triggerSubmit = async (dialogFields: any) => {
    onSubmit(dialogFields);
  }

  return (
    <Dialog
      visible={showDialog}
      style={{ width: '50vw' }}
      onHide={closeDialog}
      header={dialogMode === 'edit' ? "Edit Item" : "Add New Item"}
      position="center"
    >
      <form onSubmit={handleSubmit(onSubmit)} className="p-fluid mt-2">
        {dialogFields.map(field => (
          <div className="mb-2" key={field.id}>
            <label htmlFor={field.id} className='font-semibold'>{field.label}:</label>
            <Controller
              name={field.id}
              control={control}
              rules={{ required: field.required ? `${field.label} is required` : false }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id={field.id}
                  className='mt-1 mb-0 p-2'
                  value={field.value} // Use the correct value from react-hook-form
                  onChange={field.onChange()} // Use the onChange from react-hook-form
                />
              )}
            />
            {errors[field.id] && <small className="p-error">{(errors[field.id] as { message?: string }).message || 'Error'}</small>}
          </div>
        ))}
        <div className="p-mt-3 p-d-flex p-jc-end text-right">
          <Button type="submit" label="Save" icon="pi pi-check" className="p-button-secondary mt-3 col-3 mr-1" />
          <Button label="Cancel" icon="pi pi-times" className="p-button-secondary p-ml-2 mt-3 col-3" outlined onClick={closeDialog} />
        </div>
      </form>
    </Dialog>
  );
};
