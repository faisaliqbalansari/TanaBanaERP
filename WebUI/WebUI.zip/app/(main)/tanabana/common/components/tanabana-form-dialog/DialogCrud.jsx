
import React from 'react';
import Link from "next/link";
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';
import { InputText } from 'primereact/inputtext';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { Dialog } from 'primereact/dialog'; 
import { Button } from 'primereact/button';
import { useForm, Controller } from 'react-hook-form';
import { DialogCrudModel }  from './DialogCrudModel';

export default function DialogCrud({ showDialog: boolean, dialogCrudModel: DialogCrudFieldModel }) {

    return (
        <Dialog 
            visible = { showDialog } 
            style = {{ width: dialogCrudModel.Width, height: dialogCrudModel.Height }}
            onHide = { () => dialogCrudModel.executeOnHide() } 
            header = { dialogCrudModel.Header }
            position = { dialogCrudModel.Position }
            className = { dialogCrudModel.StyleCSS }>
          <form
            onSubmit = { () => dialogCrudModel.executeOnSubmit() }
            className="p-fluid">
            {
                dialogCrudModel.Fields.forEach(function (field) { 
                  console.log(field);
                  if(field.InputType === 1) {
                    <div className="field mb-2">
                      <label htmlFor={ field.Id } className='font-semibold'>{ field.Label }</label>
                      <Controller
                        name={ field.Id }
                        control={ control }
                        rules={{ required: (field.Label + 'Code is required') }}
                        render={({ field }) => (
                          <InputText id={ field.Id } className='mt-1 mb-0 p-2' {...field} />
                        )}/>
                      
                    </div>
                  }
                  if(field.InputType === 2) {
                  
                  }
                  if(field.InputType === 3) {
                  
                  }
                })

            }
          <div className="p-mt-3 p-d-flex p-jc-end text-right">
            <Button type="Submit" label="Save" icon="pi pi-check" className="p-button-secondary mt-3 col-3 mr-1" />
            <Button label="Cancel" icon="pi pi-times" className="p-button-secondary p-ml-2 mt-3 col-3" outlined onClick={() => executeOnCancell() } />
          </div>
        </form>
      </Dialog>
    )
}