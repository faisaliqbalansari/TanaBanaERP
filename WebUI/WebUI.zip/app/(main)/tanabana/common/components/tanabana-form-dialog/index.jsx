import React from 'react';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { Controller } from 'react-hook-form';
import { Dropdown } from 'primereact/dropdown';

export default function TBFormDialog({ formDialogConfig }) {
    const { dialog, setDialog } = formDialogConfig.DialogConfig;

    const { control, handleSubmit, errors } = formDialogConfig.FormHandler;
    
    const onClose = () => {
        if (formDialogConfig.OnClose) {
            formDialogConfig.OnClose();
        } else {
            setDialog(!dialog);
        }
    };
    return (
        <Dialog visible={dialog} style={{ width: formDialogConfig.Width, height: formDialogConfig.Height }} onHide={onClose} header={formDialogConfig.ModelName} position={formDialogConfig.ModelPosition} className={formDialogConfig.Class}>
            <form onSubmit={handleSubmit(formDialogConfig.OnSubmit)} className="p-fluid">
                <div style={{marginBottom:'20px'}} className={`overflow-y-auto`}>
                {formDialogConfig.FormFields.map((fieldData) => (
                    <React.Fragment key={fieldData.Id}>
                        <div className="field mb-2">
                            <label htmlFor={fieldData.Id} className="font-semibold">
                                {fieldData.Label}
                            </label>
                            <Controller name={fieldData.Id} control={control}
                            rules={{
                                 required: { value: fieldData.IsRequired, message: `${fieldData.Label} is required` },
                                ...(fieldData?.AdditionalRules || {}),
                            }}
                            render={({ field }) => (
                             fieldData.FieldType === "select" ?
                             <Dropdown id={fieldData.Id} invalid options={fieldData.DropdownData} optionLabel="name" 
                             placeholder={`Select a ${fieldData.Label}`} className="w-full" {...field} />:   
                            <InputText id={fieldData.Id} className="mt-1 mb-0 p-2" invalid {...field} />)
                            } />
                        </div>
                        {errors[fieldData.Id] && <small className="p-error">{errors[fieldData.Id].message}</small>}
                    </React.Fragment>
                ))}
                {formDialogConfig.ImageGallary && formDialogConfig.ImageGallary.map((image) => (
                    <>
                        <img src={image.ImageSource} alt={image.Id} />
                    </>
                ))}
                </div>
                <div className="text-right w-full bg-white absolute border-top-1 border-gray-300" style={{borderRadius:"0px 0px 5px 5px",bottom: "0px", right: "0px"}}>
                    <Button type="Submit" label={formDialogConfig.OnSubmitButtonText} icon="pi pi-check" className="p-button-secondary my-2 mr-1" />
                    <Button label={formDialogConfig.OnCanceltButtonText} icon="pi pi-times" className="p-button-secondary p-ml-2 mt-3 col-3 my-2 mr-5" outlined onClick={onClose} />
                </div>
            </form>
        </Dialog>
    );
}
