
import React from 'react';
import { BreadCrumb } from 'primereact/breadcrumb';
import Link from 'next/link';

export default function CustomBreadCrumb({navItems}) {
    const items = [
        {
            label: 'Home',
            icon: 'pi pi-home',
            template: () => <Link href="/" className="pi pi-home opacity-70"></Link>
        },
    ];

    return (
        //<BreadCrumb  {...rest} model={[...items, ...navItems]} />
        <BreadCrumb model={[...items, ...navItems]} />
    )
}
