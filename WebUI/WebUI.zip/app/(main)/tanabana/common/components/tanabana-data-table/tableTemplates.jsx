import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';

export const headerTemplate = (options, TableHeaderConfig) => {
    const className = `${options.className} justify-content-space-between`;

    return (
        <div className={className}>
            <div className="flex align-items-center gap-2">
                <span className="font-bold">{TableHeaderConfig.TableName}</span>
            </div>
            <div className="text-right flex items-center">
                {TableHeaderConfig?.Searchable && <InputText type="search" value={TableHeaderConfig.SearchQuery} onChange={(e) => TableHeaderConfig.SetSearchQuery(e.target.value)} placeholder="Search..." className="ml-2 p-1 mr-3" />}
                <Button className="p-2 mr-3 p-button-secondary" label="Add New" onClick={TableHeaderConfig.OpenDialog} />
                {options.togglerElement}
            </div>
        </div>
    );
};

export const deleteTemplate = (rowData, deleteRow) => {
    return (
        <span className="p-cursor-pointer" onClick={() => deleteRow(rowData)} style={{ cursor: 'pointer' }}>
            <i className="pi pi-trash" />
        </span>
    );
};
export const editTemplate = (rowData, openDialog) => {
    return (
        <span className="p-cursor-pointer" onClick={() => openDialog(rowData)} style={{ cursor: 'pointer' }}>
            <i className="pi pi-pencil" />
        </span>
    );
};

export const filterData = (items, searchQuery, fields) => {
    const query = searchQuery.toLowerCase();
    return items.filter((item) => fields.some((field) => item[field] && item[field].toLowerCase().includes(query)));
};
