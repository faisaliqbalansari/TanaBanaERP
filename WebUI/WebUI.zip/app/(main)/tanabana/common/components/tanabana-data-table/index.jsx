import React from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';
import { Skeleton } from 'primereact/skeleton';

export default function TBDataTable({ dataTableConfig }) {
    const { selectedData, setSelectedData } = dataTableConfig.SelectedData;
    // Render skeleton for each column
    const renderSkeletonBody = () => (
        <div className="p-d-flex p-flex-column">
            {Array(5).fill().map((_, i) => (
                <Skeleton key={i} width="100%" height="1rem" className="mb-2" />
            ))}
        </div>
    );

    return (
        <div className="pt-3 p-3">
            <Panel headerTemplate={dataTableConfig.HeaderTemplate}>
                <div className="p-2 rounded-corner">
                    <DataTable
                        value={dataTableConfig.loading ? Array(1).fill({}) : dataTableConfig.DataArray} // Render empty rows if loading
                        scrollable
                        scrollHeight="calc(100vh - 200px)"
                        editMode="row"
                        selection={selectedData}
                        onSelectionChange={(e) => setSelectedData(e.value)}
                        dataKey="id"
                        tableStyle={{ minWidth: 'calc(100% - 300px)' }}
                        onRowEditComplete={dataTableConfig.OnRowEditComplete}
                    >
                        {dataTableConfig.Columns.map((column) => (
                            <Column 
                                key={column.Id} 
                                body={dataTableConfig.loading ? renderSkeletonBody : column?.BodyTemplate} 
                                field={column?.Field} 
                                header={column.Header} 
                                style={column.Style} 
                            />
                        ))}
                    </DataTable>
                </div>
            </Panel>
        </div>
    );
}
