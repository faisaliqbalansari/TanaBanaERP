"use client";
import React, { useState, useEffect, Suspense } from "react";
import { classNames } from "primereact/utils";
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
//import { IconField } from "primereact/iconfield";
//import { InputIcon } from "primereact/inputicon";
import { Dropdown } from "primereact/dropdown";
import { InputNumber } from "primereact/inputnumber";
import { Button } from "primereact/button";
import { ProgressBar } from "primereact/progressbar";
import { Calendar } from "primereact/calendar";
import { MultiSelect } from "primereact/multiselect";
import { Slider } from "primereact/slider";
import { Tag } from "primereact/tag";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
//import { DynamicService } from "@/services/DynamicService";
import { ProgressSpinner } from "primereact/progressspinner";

const DynamicTable = ({ serviceType, columns }) => {
  const [data, setData] = useState(null);
  const [filters, setFilters] = useState(null);
  const [loading, setLoading] = useState(false);
  const [globalFilterValue, setGlobalFilterValue] = useState("");

  useEffect(() => {
    setLoading(true);
    /*
    DynamicService.getData(serviceType).then((data) => {
      setData(data);
      console.log("first : ", data);
      setLoading(false);
    });
    */
    initFilters();
  }, [serviceType]);

  const initFilters = () => {
    const initialFilters = {
      global: { value: null, matchMode: FilterMatchMode.CONTAINS },
      name: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
      description: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
      code: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
    };
    // Customize initial filters based on serviceType if needed
    setFilters(initialFilters);
    setGlobalFilterValue("");
  };

  const onGlobalFilterChange = (e) => {
    const value = e.target.value;
    let _filters = { ...filters };
    _filters["global"].value = value;
    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const clearFilter = () => {
    initFilters();
  };

  const renderHeader = () => {
    return (
      <div className="flex justify-between">
        <Button
          type="button"
          icon="pi pi-filter-slash"
          label="Clear"
          outlined
          onClick={clearFilter}
        />
       
      </div>
    );
  };

  // Filter templates
  const filterTemplates = {
    text: (options) => (
      <InputText
        value={options.value}
        onChange={(e) => options.filterCallback(e.target.value, options.index)}
        placeholder="Search"
      />
    ),
    date: (options) => (
      <Calendar
        value={options.value}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        dateFormat="mm/dd/yy"
        placeholder="mm/dd/yyyy"
        mask="99/99/9999"
      />
    ),
    number: (options) => (
      <InputNumber
        value={options.value}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        mode="currency"
        currency="USD"
        locale="en-US"
      />
    ),
    dropdown: (options, values) => (
      <Dropdown
        value={options.value}
        options={values}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        placeholder="Select One"
        className="p-column-filter"
        showClear
      />
    ),
    multiselect: (options, values) => (
      <MultiSelect
        value={options.value}
        options={values}
        onChange={(e) => options.filterCallback(e.value)}
        optionLabel="name"
        placeholder="Any"
        className="p-column-filter"
      />
    ),
    tristate: (options) => (
      <TriStateCheckbox
        value={options.value}
        onChange={(e) => options.filterCallback(e.value)}
      />
    ),
    slider: (options) => (
      <React.Fragment>
        <Slider
          value={options.value}
          onChange={(e) => options.filterCallback(e.value)}
          range
          className="m-3"
        ></Slider>
        <div className="flex align-items-center justify-content-between px-2">
          <span>{options.value ? options.value[0] : 0}</span>
          <span>{options.value ? options.value[1] : 100}</span>
        </div>
      </React.Fragment>
    ),
  };

  const header = renderHeader();

  const textEditor = (options) => {
    return (
      <InputText
        type="text"
        value={options.value}
        onChange={(e) => options.editorCallback(e.target.value)}
      />
    );
  };

  const filterClearTemplate = (options) => {
    return (
      <Button
        type="button"
        icon="pi pi-times"
        onClick={options.filterClearCallback}
        severity="secondary"
      ></Button>
    );
  };

  const filterApplyTemplate = (options) => {
    return (
      <Button
        type="button"
        icon="pi pi-check"
        onClick={options.filterApplyCallback}
        severity="success"
      ></Button>
    );
  };
  const filterFooterTemplate = () => {
    return <div className="px-3 pt-0 pb-3 text-center">Filter by Country</div>;
  };
  const allowEdit = (rowData) => {
    return rowData.name !== "Blue Band";
  };
  const onRowEditComplete = (e) => {
    
    let _products = [...data];
    let { newData, index } = e;
    console.log("first : ",e)
    _products[index] = newData;

    setData(_products);
  };
  return (
    <>
      <div className="w-full">
        <DataTable
          scrollable
          scrollHeight="50vh"
          editMode="row" 
          onRowEditComplete={onRowEditComplete}
          value={data}
          paginator
          showGridlines
          rows={10}
          loading={loading}
          dataKey="id"
          filters={filters}
          header={header}
          globalFilterFields={["name", "code", "description", "stateId"]}
          emptyMessage="No data found."
        >
          {columns.map((col) => (
            <Column
              key={col.field}
              field={col.field}
              filterField={col.field}
              filterPlaceholder="Search by country"
              header={col.header}
              editor={(options) => textEditor(options)}
              filter
              filterElement={(options) =>
                filterTemplates[col.filterType](options, col.body)
              }
              body={col.body}
              filterClear={filterClearTemplate}
              filterFooter={filterFooterTemplate}
              filterApply={filterApplyTemplate}
              style={{ minWidth: "12rem" }}
            />
          ))}
          <Column
            rowEditor={allowEdit}
            header={"Edit"}
          ></Column>
        </DataTable>
      </div>
    </>
  );
};

export default DynamicTable;
