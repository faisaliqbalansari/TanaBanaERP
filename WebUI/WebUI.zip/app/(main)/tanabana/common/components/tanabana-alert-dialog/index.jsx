import React from 'react';
import { ConfirmDialog } from 'primereact/confirmdialog';

export default function TBAlertDialog({ alertDialogConfig }) {
    const { dialog, setDialog } = alertDialogConfig.ConfirmationDialogConfig;

    const onReject = () => {
        if (alertDialogConfig.OnReject) {
            alertDialogConfig.OnReject();
        } else {
            setDialog(false);
        }
    };
    return (
        <ConfirmDialog
            visible={dialog}
            onHide={onReject}
            message={alertDialogConfig.Message}
            header={alertDialogConfig.HeaderText}
            icon={alertDialogConfig?.Icon}
            acceptClassName={alertDialogConfig?.ConfirmButtonClass}
            acceptIcon={alertDialogConfig?.ConfirmIcon}
            acceptLabel={alertDialogConfig?.ConfirmButtonLabel}
            rejectClassName={alertDialogConfig?.RejectButtonClass}
            rejectIcon={alertDialogConfig?.RejectIcon}
            rejectLabel={alertDialogConfig?.RejectButtonLabel}
            accept={alertDialogConfig?.OnConfirm}
            reject={onReject}
        />
    );
}