import { Button } from 'primereact/button'
import React from 'react'

const TableHeader = ({heading, handleAddNew}) => {
  return (
    <div className='flex justify-between px-5 items-center bg-white py-2'>
        <h1 className='font-bold text-2xl'>{heading}</h1>
        <Button onClick={handleAddNew}>Add New</Button>
    </div>
  )
}

export default TableHeader