const TBProgressSpinner = () => {
    const containerStyle = {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '80vh',
        width: '80vw',
        position: 'relative'
    };

    const loaderStyle = {
        width: '50px',
        aspectRatio: '1',
        color: '#4B5563',
        opacity:.8,
        position: 'relative',
        animation: 'l40 0.5s infinite alternate'
    };

    const loaderBeforeAfterStyle = {
        content: '""',
        position: 'absolute',
        inset: '0',
        backgroundSize: '25px 25px',
        backgroundPosition: '0 0, 100% 0, 100% 100%, 0 100%',
        backgroundRepeat: 'no-repeat'
    };

    const keyframes = `
            @keyframes l40-1 {
                0%, 10%, 90%, 100% { inset: 0; }
                40%, 60% { inset: -10px; }
            }
            
            @keyframes l40-2 {
                0%, 40% { transform: rotate(0); }
                60%, 100% { transform: rotate(90deg); }
            }
            
            @keyframes l40 {
                0%, 100% { transform: rotate(0); }
            }
        `;

    return (
        <div style={containerStyle}>
            <div style={loaderStyle}>
                <div
                    style={{
                        ...loaderBeforeAfterStyle,
                        backgroundImage: `
                                radial-gradient(farthest-side at top left, currentColor 96%, #0000),
                                radial-gradient(farthest-side at top right, currentColor 96%, #0000),
                                radial-gradient(farthest-side at bottom right, currentColor 96%, #0000),
                                radial-gradient(farthest-side at bottom left, currentColor 96%, #0000)`,
                        animation: 'l40-1 1s infinite'
                    }}
                />
                <div
                    style={{
                        ...loaderBeforeAfterStyle,
                        backgroundImage: `
                                radial-gradient(farthest-side at top left, #0000 94%, currentColor 96%),
                                radial-gradient(farthest-side at top right, #0000 94%, currentColor 96%),
                                radial-gradient(farthest-side at bottom right, #0000 94%, currentColor 96%),
                                radial-gradient(farthest-side at bottom left, #0000 94%, currentColor 96%)`,
                        animation: 'l40-2 1s infinite'
                    }}
                />
            </div>
            <style>{keyframes}</style>
        </div>
    );
};

export default TBProgressSpinner