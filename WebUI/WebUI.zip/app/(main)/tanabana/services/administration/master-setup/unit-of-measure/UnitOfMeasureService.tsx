import { IUnitOfMeasure } from '@/app/(main)/tanabana/services/administration/master-setup/unit-of-measure/IUnitOfMeasure';
import { EntityServiceBase } from '../../../EntityServiceBase'; 

export class UnitOfMeasureService extends EntityServiceBase {

    public async getUnitOfMeasures(): Promise<IUnitOfMeasure[]> {
        const that = this;
        let endpoint = 'api/UnitOfMeasureSetup/GetUnitOfMeasures';
        return that.httpGet(endpoint);
    }

    public async saveUnitOfMeasure(updatedUnitOfMeasure: IUnitOfMeasure): Promise<void> {
        const that = this;
        let endpoint = 'api/UnitOfMeasureSetup/SaveUnitOfMeasure';
        return that.httpPost(endpoint, updatedUnitOfMeasure);
    }

    public async deleteUnitOfMeasure(id: string): Promise<void> {
        const that = this;
        let endpoint = 'api/UnitOfMeasureSetup/DeleteUnitOfMeasure';
        return that.httpDelete(endpoint, id );
    }
}
