
export interface IUnitOfMeasure {
    id: number;
    code: string;
    name: string;
    description: string;
    disabled: boolean;
  }
  