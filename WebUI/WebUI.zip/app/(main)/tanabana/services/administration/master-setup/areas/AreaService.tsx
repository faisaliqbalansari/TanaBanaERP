import { CitiesService} from '../cities/CitiesService';
import { IAreas } from './IAreas';

export class AreaService extends CitiesService {

    public async getCityAreas(cityId: number = -1): Promise<IAreas[]> {
        const endpoint = `api/AddressSetup/GetCityAreas?cityId=${cityId}`;
        return this.httpGet(endpoint);
    }

    public async saveCityArea(area: IAreas): Promise<void> {
        const endpoint = 'api/AddressSetup/SaveCityArea';
        return this.httpPost(endpoint, area);
    }

    public async deleteCityArea(id: string): Promise<void> {
        const endpoint = 'api/AddressSetup/DeleteCityArea';
        return this.httpDelete(endpoint, id);
    }
}
