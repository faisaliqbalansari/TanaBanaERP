export class IAreas{
    id: number;
    countryId: number;
    countryName: string;
    provinceId: number;
    provinceName: string;
    code: string;
    name: string;
    description: string;
    cityId : number;
    cityName : string;
    constructor() {
        this.id = 0;
        this.countryId = 0;
        this.countryName = "";
        this.provinceId = 0;
        this.provinceName = '';
        this.code = '';
        this.name = '';
        this.description = '';
        this.cityId = 0;
        this.cityName = '';
    }
}
