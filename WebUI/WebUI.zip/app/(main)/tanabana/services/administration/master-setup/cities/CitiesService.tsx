import { ICity } from './ICities';
import { ProvinceService } from '../provinces/ProvinceService';

export class CitiesService extends ProvinceService {

    public async getCities(provinceId: number = -1, id: number = -1): Promise<ICity[]> {
        const endpoint = `api/AddressSetup/GetCities?provinceId=${provinceId}&id=${id}`;
        return this.httpGet(endpoint);
    }

    public  async saveCity(city: ICity): Promise<void> {
        const endpoint = 'api/AddressSetup/SaveCity';
        return this.httpPost(endpoint, city);
    }

    public async deleteCity(id: string): Promise<void> {
        const endpoint = 'api/AddressSetup/DeleteCity';
        return this.httpDelete(endpoint, id);
    }
}
