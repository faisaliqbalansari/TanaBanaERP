

export class Province {
    id: number;
    countryId: number;
    code: string;
    name: string;
    description: string;
    //countryCode: string;
    //countryName: string;
    // Add more properties if needed

    constructor() {
      this.id = 0;
      this.countryId = 0;
      this.code = '';
      this.name = '';
      this.description = '';
      //this.countryCode = "";
      //this.countryName = "";
    }
    
  }