import { ICountry } from '@/app/(main)/tanabana/services/administration/master-setup/countries/ICountry'; 
import { EntityServiceBase } from '../../../EntityServiceBase'; 

export class CountryService extends EntityServiceBase {

    public async getCountries(): Promise<ICountry[]> {
        const that = this;
        let endpoint = 'api/AddressSetup/GetCountries';
        return that.httpGet(endpoint);
    }

    public async saveCountries(updatedCountry: ICountry): Promise<void> {
        const that = this;
        let endpoint = 'api/AddressSetup/SaveCountry';
        return that.httpPost(endpoint, updatedCountry);
    }

    public async deleteCountry(countryId: string): Promise<void> {
        const that = this;
        let endpoint = 'api/AddressSetup/DeleteCountry';
        return that.httpDelete(endpoint, countryId );
    }
}


/*
import { Demo } from '@/types';

export const CountryService = {
    getCountries() {
        return fetch('/demo/data/countries.json', { headers: { 'Cache-Control': 'no-cache' } })
            .then((res) => res.json())
            .then((d) => d.data as Demo.Country[]);
    }
};
*/