
export interface ICountry {
    id: number;
    code: string;
    name: string;
    // Add more properties if needed
  }
  