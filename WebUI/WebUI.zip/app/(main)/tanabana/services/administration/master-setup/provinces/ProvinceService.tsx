import { Province } from './IProvince';
import { CountryService } from '../../master-setup/countries/CountryService';

export class ProvinceService extends CountryService {

    public async getProvinces(countryId: number = -1, provinceId: number = -1): Promise<Province[]> {
        let endpoint = 'api/AddressSetup/GetProvinces?countryId=' + countryId + '&provinceId=' + provinceId;
        return this.httpGet(endpoint);
    }

    public async saveProvince(province: Province): Promise<void> {
        let endpoint = 'api/AddressSetup/SaveProvince';
        return this.httpPost(endpoint, province);
    }
        
    public async deleteProvince(id: string): Promise<void> {
        let endpoint = 'api/AddressSetup/DeleteProvince';
        return this.httpDelete(endpoint, id);
    }
}