
export class AuthModel {
  public UserId: string;
  public UserName: string;
  public Roles: string;
  public Token: string;
  public Expiry: number;
  public LoginDate: Date;

  constructor (){
    this.UserId = '';
    this.UserName = '';
    this.Roles = '';
    this.Token = '';
    this.Expiry = 0;
    this.LoginDate = new Date();
  }

  public isUserAuthenticated(): Boolean  {
    const that = this;
    let today = new Date();
    let loginDate: Date = new Date(that.LoginDate);

    /*
    alert('Year: ' + loginDate.getFullYear());
    alert('Month: ' + ((loginDate.getMonth()) + 1));
    alert('Day: ' + loginDate.getDate());
    alert('Hours: ' + loginDate.getHours());
    alert('Minutes: ' + loginDate.getMinutes());
    */
    let loginExpiryDate = new Date(
                          loginDate.getFullYear(),
                          ((loginDate.getMonth()) + 1),
                          loginDate.getDate(),
                          (loginDate.getHours() + that.Expiry),
                          loginDate.getMinutes());

    //alert(loginExpiryDate >= loginDate);
    let authenticated: Boolean = that.Token !== undefined &&
                                    that.Token !== null &&
                                    that.Token !== '' &&
                                    loginExpiryDate >= loginDate;
    return authenticated;
  }

}
  