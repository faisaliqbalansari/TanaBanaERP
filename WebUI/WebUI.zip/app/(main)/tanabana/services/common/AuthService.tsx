import { AuthModel } from './AuthModel'; 
import { EntityServiceBase } from '../EntityServiceBase'; 

export class AuthService extends EntityServiceBase {

    public async getToken(authData: any): Promise<boolean> {
        const that = this;
        let endpoint = 'api/Login/GetToken';
        /* Acutal Implementation */
        //let response: any =  this.userLogin(endpoint, data);
        const res = await this.userLogin(endpoint, authData).then((result) =>
            { 
                if(!result.ok)
                {
                    throw new Error('Error: Failed to Login. Please Contact Administator.');
                }
                else {
                    return result.json();
                }
            }
            //let temp2 = temp;
        )
        .then((data) => data as AuthModel);

        let result: any = res;
        let authModel: AuthModel = new AuthModel();
        authModel.Token = result.token;
        authModel.UserName = result.userName;
        authModel.Expiry = result.expiry;
        authModel.LoginDate = new Date();

        this.setAuthModel(authModel);
        
        return true;
        
       
       /** Mockup login 
        if(data.UserId === 'admin' && data.Password === '1234') {
            const authModel: AuthModel = new AuthModel();
            authModel.Token = 'Test Token 12345 Issues';
            authModel.UserId = 'admin';
            authModel.UserName = 'Administrator Test User';
            authModel.Roles = 'Administrator';
            this.setAuthModel(authModel);
    
            return true;
        }
        else {
            throw new Error('Invalid User ID/Password');
            return false;
        }
        */
    }

    public async erpLogout() {

        let authModel = this.getAuthModel();
        authModel.Expiry = 0;
        authModel.LoginDate = new Date();
        authModel.Token = '';
        authModel.Roles = '';
        authModel.UserName = '';
        authModel.UserId = '';

        this.setAuthModel(authModel);

        return true;
    }
}


/*
import { Demo } from '@/types';

export const CountryService = {
    getCountries() {
        return fetch('/demo/data/countries.json', { headers: { 'Cache-Control': 'no-cache' } })
            .then((res) => res.json())
            .then((d) => d.data as Demo.Country[]);
    }
};
*/