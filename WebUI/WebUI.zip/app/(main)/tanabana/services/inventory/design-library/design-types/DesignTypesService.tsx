import {IDesignTypes } from './IDesignTypes'
import { EntityServiceBase } from '../../../EntityServiceBase'; 

export class DesignTypesService extends EntityServiceBase {

    public async getDesignTypes(): Promise<IDesignTypes []> {
        const that = this;
        let endpoint = 'api/Design/GetDesignTypes'
        return that.httpGet(endpoint);
    }

    public async saveDesignTypes(updatedDesignTypes: IDesignTypes ): Promise<void> {
        const that = this;
        let endpoint = 'api/Design/SaveDesignType';
        return that.httpPost(endpoint, updatedDesignTypes);
    }

    public async deleteDesignTypes(id: string): Promise<void> {
        const that = this;
        let endpoint = 'api/Design/DeleteDesignType';
        return that.httpDelete(endpoint, id );
    }
}
