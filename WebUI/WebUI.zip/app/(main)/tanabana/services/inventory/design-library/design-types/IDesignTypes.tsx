export interface IDesignTypes {
    id : number;
    code: string;
    name: string;
    description: string;
  }