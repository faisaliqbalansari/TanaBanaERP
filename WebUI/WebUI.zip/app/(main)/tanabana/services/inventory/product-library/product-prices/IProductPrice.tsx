export interface IProductPrice {
    id : number;
    code: string;
    name: string;
    description: string;
    IsMaterialCategory: boolean;
  }