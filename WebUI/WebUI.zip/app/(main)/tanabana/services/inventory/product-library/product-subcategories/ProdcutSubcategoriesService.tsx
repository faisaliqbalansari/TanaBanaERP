import {IProductSubcategories} from './IProductSubcategories'
import { ProductCategoriesService } from '../product-categories/ProductCategoriesService';

export class ProductSubcategoriesService extends ProductCategoriesService {

    public async getProductSubcategories(categoryId: number =-1): Promise<IProductSubcategories[]> {
        const that = this;
        let endpoint = 'api/Product/GetProductSubcategories?categoryId=' + categoryId;
        return that.httpGet(endpoint);
    }

    public async saveProductSubcategories(updatedProductSubcategory: IProductSubcategories): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/SaveProductSubcategory';
        return that.httpPost(endpoint, updatedProductSubcategory);
    }

    public async deleteProductSubcategories(id: string): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/DeleteProductSubcategory';
        return that.httpDelete(endpoint, id );
    }
}
