export interface IProductSubcategories {
    id : number;
    code: string;
    name: string;
    parentCode: string;
    parentName: string;
    parentCategoryId: number;
    IsMaterialCategory: boolean;
  }