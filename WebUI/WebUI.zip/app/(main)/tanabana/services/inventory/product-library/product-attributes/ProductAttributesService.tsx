import {IProductAttributes} from './IProductAttributes'
import { EntityServiceBase } from '../../../EntityServiceBase'; 

export class ProductAttributesService extends EntityServiceBase {

    public async getProductAttribues(): Promise<IProductAttributes[]> {
        const that = this;
        let endpoint = 'api/Product/GetProductAttributes';
        return that.httpGet(endpoint);
    }

    public async saveProductAttributes(updatedProductAttributes: IProductAttributes): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/SaveProductAttribute';
        return that.httpPost(endpoint, updatedProductAttributes);
    }

    public async deleteProductAttributes(id: string): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/DeleteProductAttribute';
        return that.httpDelete(endpoint, id );
    }
}
