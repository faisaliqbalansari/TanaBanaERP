import {IProductCategories} from './IProductCategories'
import { EntityServiceBase } from '../../../EntityServiceBase'; 

export class ProductCategoriesService extends EntityServiceBase {

    public async getProductCategories(categoryId: number =-1): Promise<IProductCategories[]> {
        const that = this;
        let endpoint = 'api/Product/GetProductCategories?categoryId=' + categoryId;
        return that.httpGet(endpoint);
    }

    public async saveProductCategories(updatedProductCategories: IProductCategories): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/SaveProductCategory';
        return that.httpPost(endpoint, updatedProductCategories);
    }

    public async deleteProductCategories(id: string): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/DeleteProductCategory';
        return that.httpDelete(endpoint, id );
    }
}
