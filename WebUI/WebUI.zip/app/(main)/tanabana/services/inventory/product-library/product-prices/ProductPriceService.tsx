import {IProductPrice} from './IProductPrice';
import { EntityServiceBase } from '../../../EntityServiceBase'; 

export class ProductPriceService extends EntityServiceBase {

    public async getProductPrices(): Promise<IProductPrice[]> {
        const that = this;
        let endpoint = 'api/Product/GetProductPrices';
        return that.httpGet(endpoint);
    }

    public async saveProductPrice(updatedProductPrice: IProductPrice): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/SaveProductPrice';
        return that.httpPost(endpoint, updatedProductPrice);
    }

    public async deleteProductPrice(id: string): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/DeleteProductPrice';
        return that.httpDelete(endpoint, id );
    }
}
