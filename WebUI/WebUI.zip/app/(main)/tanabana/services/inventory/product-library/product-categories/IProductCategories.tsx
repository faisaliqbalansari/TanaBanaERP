export interface IProductCategories {
    id : number;
    code: string;
    name: string;
    description: string;
    ParentCategoryId: number;
    IsMaterialCategory: boolean;
  }