export interface IProduct {
    id : number;
    categoryId: number;
    categoryCode: string;
    categoryName: string;
    subcategoryId: string;
    subcategoryCode: string;
    subcategoryName: string;
    code: string;
    name: string;
    description: string;
    productURL: string;
    unitOfMeasureId: number;
    discounted: boolean; 
  }