import {IProduct} from './IProduct';
import { EntityServiceBase } from '../../../EntityServiceBase'; 

export class ProductService extends EntityServiceBase {

    public async getProducts(): Promise<IProduct[]> {
        const that = this;
        let endpoint = 'api/Product/GetProducts';
        return that.httpGet(endpoint);
    }

    public async saveProduct(updatedProductCategories: IProduct): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/SaveProduct';
        return that.httpPost(endpoint, updatedProductCategories);
    }

    public async deleteProduct(id: string): Promise<void> {
        const that = this;
        let endpoint = 'api/Product/DeleteProduct';
        return that.httpDelete(endpoint, id );
    }
}
