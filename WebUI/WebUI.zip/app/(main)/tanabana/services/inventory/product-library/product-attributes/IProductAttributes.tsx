export interface IProductAttributes {
    id : number;
    code: string;
    name: string;
    description: string;
    IsMaterialCategory: boolean;
  }