
import { AuthModel }  from '@/app/(main)/tanabana/services/common/AuthModel';

export class EntityServiceBase {

    public static ServiceBaseUrl: string = 'http://localhost/TanaBanaApi/';
    //public static ServiceBaseUrl: string = 'https://localhost:44314/';
    
    public static ERPLoginUrl: string = '/auth/erplogin';
    public static ERPHomeUrl: string = '/';
    public isLoading: boolean = false;
    
    public static AuthModel: AuthModel = new AuthModel(); 

    public httpGet(endpoint: string): Promise<any[]> {
        const that = this;
        let url = EntityServiceBase.ServiceBaseUrl + endpoint;
        that.isLoading = true;
        return fetch(url, {
            headers: {
                'Cache-Control': 'no-cache'
            }
        })
        .then((res) => res.json())
        .then((data) => {
            that.isLoading = false;
            return( data as any[] )});
    }

    public httpPost(endpoint: string, params: any ): Promise<void> {
        const that = this;
        let url = EntityServiceBase.ServiceBaseUrl + endpoint;
        that.isLoading = true;
        return fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(params),
        })
        .then((res) => {
            that.isLoading = false;
            if (!res.ok) {
                throw new Error('Error: Failed to save/update record. Please contact administator.');
            }
        });
    }

    public httpDelete(endpoint: string, recordId: any): Promise<void> {
        let url = EntityServiceBase.ServiceBaseUrl + endpoint + '?id=' + recordId;
        return fetch(url, {
            method: 'DELETE'
        })
        .then((res) => {
            if (!res.ok) {
                throw new Error('Error: Failed to delete record. Please contact administator.');
            }
        });
    }

    public userLogin(endpoint: string, params: any ): Promise<any> {
        let url = EntityServiceBase.ServiceBaseUrl + endpoint;
        return fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(params),
        });
        /*.then((res) => {
            if (!res.ok) {
                console.log(res);
                throw new Error('Error: Failed to login. Please contact administator.');
            }
            else {
                let jsonData = res.Response.json();

                localStorage.setItem('auth', JSON.stringify(jsonData));

                return res;//(jsonData); 
            }
        });
        */
    }

    public isUserAuthenticated(): Boolean {
        let authModel: AuthModel = this.getAuthModel();
        if(authModel) {
            return EntityServiceBase.AuthModel.isUserAuthenticated();
        }
        else {
            return false;
        }
    }

    public getERPLoginUrl(): string {
        return EntityServiceBase.ERPLoginUrl;
    }

    public getERPHomeUrl(): string {
        return EntityServiceBase.ERPHomeUrl;
    }

    public getAuthModel(): AuthModel {
        
        let authModel: AuthModel = new AuthModel();

        if(EntityServiceBase.AuthModel && EntityServiceBase.AuthModel.Token !== '') {
            return EntityServiceBase.AuthModel;
        }
        else {
            let strJson = localStorage.getItem('authModel');
            if(strJson) {
                let temp = JSON.parse(strJson) as AuthModel;
                authModel.Token = temp.Token;
                authModel.UserName = temp.UserName;
                authModel.Expiry = temp.Expiry;
                authModel.LoginDate = new Date(temp.LoginDate);// (temp.LoginDate as Date);
            }

            if(authModel && authModel.Token !== '') {
                EntityServiceBase.AuthModel = authModel;
            }

            return EntityServiceBase.AuthModel;
        }
    }

    public setAuthModel(authModel: AuthModel): void {
        EntityServiceBase.AuthModel = authModel;
        localStorage.setItem('authModel', JSON.stringify(authModel));
    }

}
