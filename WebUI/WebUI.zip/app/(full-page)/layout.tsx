import { Metadata } from 'next';
import AppConfig from '../../layout/AppConfig';
import React from 'react';

import '@/styles/tanabana/basethemeoverrides.scss';
import '@/styles/tanabana/erpresponsive.scss';
import '@/styles/tanabana/erp.scss';

interface SimpleLayoutProps {
    children: React.ReactNode;
}

export const metadata: Metadata = {
    title: 'Tana Bana',
    description: 'Tana Bana'
};

export default function SimpleLayout({ children }: SimpleLayoutProps) {
    return (
        <React.Fragment>
            {children}
            <AppConfig simple />
        </React.Fragment>
    );
}
