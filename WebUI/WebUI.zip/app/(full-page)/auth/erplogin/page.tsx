/* eslint-disable @next/next/no-img-element */
'use client';
import { useRouter } from 'next/navigation';
import React, { useContext, useState, useEffect } from 'react';
import { Panel } from 'primereact/panel';
import { Checkbox } from 'primereact/checkbox';
import { Button } from 'primereact/button';
import { Password } from 'primereact/password';
import { LayoutContext } from '../../../../layout/context/layoutcontext';
import { InputText } from 'primereact/inputtext';
import { classNames } from 'primereact/utils';

import { AuthService } from '@/app/(main)/tanabana/services/common/AuthService';
import '@/styles/tanabana/erpvariables.scss';

const ErpLoginPage = () => {
    const service = new AuthService();
    const [userId, setUserId] = useState('');
    const [password, setPassword] = useState('');
    const [checked, setChecked] = useState(false);
    const { layoutConfig } = useContext(LayoutContext);

    const router = useRouter();
    const containerClassName = classNames('surface-ground flex align-items-center justify-content-center min-h-screen min-w-screen overflow-hidden', { 'p-input-filled': layoutConfig.inputStyle === 'filled' });

    useEffect(() => {
        setUserId('admin');
        setPassword('1234');
    }, []);
        
    const onLogin = async () => {
        if (!userId || !password) {
          alert('Please Provide User Id/Password');
          return;
        }
    
        const userData = {
          UserId: userId,
          Password: password
        };
    
        try {
            const isUserLoggedIn: boolean = await service.getToken(userData);
            if(isUserLoggedIn) {
                console.log('User Signed in successfully');
                router.push(service.getERPHomeUrl());
            }
        }
        catch (error) {
            alert('' + error);
            //console.error('Error in sign in:', error);
        }
      };

      const headerTemplate = (options: any) => {
        const className = `${options.className} justify-content-center`;
    
        return (
          <div className={className}>
            <div className="align-items-center text-center">
              <span className="font-bold123 text-center" style={{fontSize:'17px'}}>Sign In</span>
            </div>
          </div>
        );
      };

    return (
        <div className={containerClassName}>
            
                <div className="flex flex-column align-items-center justify-content-center">
                    {/*
                        <img src={`/layout/images/logo-${layoutConfig.colorScheme === 'light' ? 'dark' : 'white'}.svg`} alt="Sakai logo" className="mb-5 w-6rem flex-shrink-0" />
                        <img src={`/layout/images/logo.avif`} width="160px" height={'60px'} alt="logo" />
                        <h3 style={{color: '#333', marginTop: '15px', marginLeft: '10px', fontFamily:'sans-serif', fontSize: '30px'}}>Hassan's</h3>
                    */}
                    <img src={`/layout/images/HassansLogo.png`} width="180px" height={'35px'} alt="logo" />
                    <div
                        className='mt-4'
                        style={{/*
                            borderRadius: '56px',
                            padding: '0.3rem',
                            background: 'linear-gradient(180deg, #333 10%, rgba(33, 150, 243, 0) 30%)'
                        */}}
                    >
                        <Panel headerTemplate={headerTemplate}>
                        <div className="w-full surface-card py-8 px-5 sm:px-8" style={{ borderRadius: '53px' }}>
                            <div className="text-center mb-5">
                                {/*
                                <img src="/demo/images/login/avatar.png" alt="Image" height="50" className="mb-3" />
                                
                                <div className="text-900 text-3xl font-medium mb-3">Signin</div>
                                */}
                                {/*<span className="text-600 font-medium">Sign in to continue</span>*/}
                            </div>

                            <div>
                                <label htmlFor="email1" className="block text-900 text-md font-medium mb-2">
                                    Email
                                </label>
                                <InputText id="userId" type="text" value={userId} onChange={(e) => setUserId(e.target.value)} placeholder="User ID" className="w-full md:w-50rem mb-5" style={{ padding: '1rem' }} />

                                <label htmlFor="txtPassword" className="block text-900 font-medium text-md mb-2">
                                    Password
                                </label>
                                <Password inputId="txtPassword" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password"  className="w-full md:w-50rem mb-5"></Password>
                                {/*
                                <div className="flex align-items-center justify-content-between mb-5 gap-5">
                                    <div className="flex align-items-center">
                                        <Checkbox inputId="rememberme1" checked={checked} onChange={(e) => setChecked(e.checked ?? false)} className="mr-2"></Checkbox>
                                        <label htmlFor="rememberme1">Remember me</label>
                                    </div>
                                    
                                    <a className="font-medium no-underline ml-2 text-right cursor-pointer" style={{ color: 'var(--primary-color)' }}>
                                        Forgot password?
                                    </a>
                                    
                                </div>
                                */}
                                <div className='text-center'>
                                <Button label="Sign In" className="p-2 p-button-secondary justify-content-center" style={{fontSize: '13px'}} onClick={() => onLogin()}></Button>
                                </div>
                                
                            </div>
                        </div>
                        </Panel>
                    </div>
                </div>
        </div>
    );
};

export default ErpLoginPage;
