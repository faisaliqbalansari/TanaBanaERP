'use client'
import React, { createContext, useContext, useRef, ReactNode } from 'react';
import { Toast, ToastMessage } from 'primereact/toast';
import { title } from 'process';

// Define the shape of the context value
interface ToastContextType {
  current: Toast | null;
}

// Create the Toast context
const ToastContext = createContext<ToastContextType | undefined>(undefined);

export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const toastRef = useRef<Toast>(null);

  return (
    <ToastContext.Provider value={toastRef}>
      {children}
      <Toast ref={toastRef} />
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const toastRef = useContext(ToastContext);

  if (toastRef === undefined) {
    throw new Error('useToast must be used within a ToastProvider');
  }

  return {
    success: (title: string, message: string) => toastRef.current?.show({ severity: 'success', summary: title, detail: message, life: 5000 }),
    error: (title: string, message: string) => toastRef.current?.show({ severity: 'error', summary: title, detail: message, life: 5000 }),
    info: (title: string, message: string) => toastRef.current?.show({ severity: 'info', summary: title, detail: message, life: 5000 }),
    warn: (title: string, message: string) => toastRef.current?.show({ severity: 'warn', summary: title, detail: message, life: 5000 }),
  };
};
