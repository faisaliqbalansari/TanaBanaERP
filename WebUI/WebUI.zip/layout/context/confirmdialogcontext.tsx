'use client'
import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { ConfirmDialog } from 'primereact/confirmdialog';


interface ConfirmDialogContextType {
    show: (message: string, onConfirm: () => void, onCancel: () => void) => void;
  }

const ConfirmDialogContext = createContext<ConfirmDialogContextType | undefined>(undefined);

export const ConfirmDialogProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [visible, setVisible] = useState(false);
  const [message, setMessage] = useState('');
  const [onConfirm, setOnConfirm] = useState<() => void>(() => () => {});
  const [onCancel, setOnCancel] = useState<() => void>(() => () => {});

  const show = useCallback((message: string, onConfirm: () => void, onCancel: () => void) => {
    setMessage(message);
    setOnConfirm(() => onConfirm);
    setOnCancel(() => onCancel);
    setVisible(true);
  }, []);
  const confirm = () => {
    onConfirm();
    setVisible(false);
  };

  const cancel = () => {
    onCancel();
    setVisible(false);
  };

  return (
    <ConfirmDialogContext.Provider value={{ show }}>
      {children}
      <ConfirmDialog
        visible={visible}
        onHide={cancel}
        message={message}
        header="Confirmation"
        icon="pi pi-exclamation-triangle"
        acceptClassName="p-button-secondary"
        acceptIcon="pi pi-check"
        acceptLabel="Yes"
        rejectClassName="p-button-secondary"
        rejectLabel="No"
        accept={confirm}
        reject={cancel}
      />
    </ConfirmDialogContext.Provider>
  );
};

export const useConfirmDialog = () => {
  const context = useContext(ConfirmDialogContext);

  if (context === undefined) {
    throw new Error('useConfirmDialog must be used within a ConfirmDialogProvider');
  }

  return context;
};