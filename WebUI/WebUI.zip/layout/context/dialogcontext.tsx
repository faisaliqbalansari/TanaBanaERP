'use client'
import React, { createContext, useState, useContext, ReactNode } from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { useForm, Controller } from 'react-hook-form';

interface DialogField {
  id: string;
  label: string;
  inputType: 'text' | 'textarea';
  required: boolean;
  value?: string;
  onChange?: any;
}

interface DialogContextType {
  showDialog: boolean;
  dialogMode: 'add' | 'edit' | null;
  formData: any;
  dialogFields: DialogField[];
  openDialog: (mode: 'add' | 'edit', data?: any) => void;
  closeDialog: () => void;
  setFormData: (data: any) => void;
  setDialogFields: (fields: DialogField[]) => void;
  onsubmit?: (data: any) => void; 
}

const DialogContext = createContext<DialogContextType | undefined>(undefined);

export const DialogProvider: React.FC<{ children: ReactNode, onsubmit?: (data: any) => void }> = ({ children, onsubmit }) => {
  const [showDialog, setShowDialog] = useState(false);
  const [dialogMode, setDialogMode] = useState<'add' | 'edit' | null>(null);
  const [formData, setFormData] = useState<any>({});
  const [dialogFields, setDialogFields] = useState<DialogField[]>([]);

  const openDialog = (mode: 'add' | 'edit', data?: any) => {
    setDialogMode(mode);
    setFormData(data || {});
    setShowDialog(true);
  };

  const closeDialog = () => {
    setShowDialog(false);
    setDialogMode(null);
    setFormData({});
  };

  const defaultValues = dialogFields.reduce((acc, field) => ({
    ...acc,
    [field.id]: formData?.[field.id] || field.value || ''
  }), {} as Record<string, string>);

  const { control, handleSubmit, formState: { errors } } = useForm({
    defaultValues
  });

  const handleSubmitForm = (data: Record<string, any>) => {
    if (onsubmit) {
      onsubmit(data);
    }
    closeDialog();
  };

  const dialogContent = (
    <Dialog
      visible={showDialog}
      style={{ width: '50vw' }}
      onHide={closeDialog}
      header={dialogMode === 'edit' ? "Edit Item" : "Add New Item"}
      position="center"
    >
      <form onSubmit={handleSubmit(handleSubmitForm)} className="p-fluid mt-2">
        {dialogFields.map(field => (
          <div className="mb-2" key={field.id}>
            <label htmlFor={field.id} className='font-semibold'>{field.label}:</label>
            <Controller
              name={field.id}
              control={control}
              rules={{ required: field.required && `${field.label} is required` }}
              render={({ field: { onChange, value } }) => (
                <InputText
                  id={field.id}
                  className='mt-1 mb-0 p-2'
                  value={field.value}
                  onChange={field.onChange()}
                />
              )}
            />
            {errors[field.id] && <small className="p-error">{errors[field.id]?.message}</small>}
          </div>
        ))}
        <div className="p-mt-3 p-d-flex p-jc-end text-right">
          <Button type="submit" label="Save" icon="pi pi-check" className="p-button-secondary mt-3 col-3 mr-1" />
          <Button label="Cancel" icon="pi pi-times" className="p-button-secondary p-ml-2 mt-3 col-3" outlined onClick={closeDialog} />
        </div>
      </form>
    </Dialog>
  );

  const value = {
    showDialog,
    dialogMode,
    formData,
    dialogFields,
    openDialog,
    closeDialog,
    setFormData,
    setDialogFields,
    onsubmit
  };

  return (
    <DialogContext.Provider value={value}>
      {children}
      {dialogContent}
    </DialogContext.Provider>
  );
};

export const useDialog = (): DialogContextType => {
  const context = useContext(DialogContext);
  if (!context) {
    throw new Error('useDialog must be used within a DialogProvider');
  }
  return context;
};
