/* eslint-disable @next/next/no-img-element */

import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { classNames } from 'primereact/utils';
import React, { forwardRef, useContext, useImperativeHandle, useRef } from 'react';
import { AppTopbarRef } from '@/types';
import { LayoutContext } from './context/layoutcontext';

import { AuthService } from '@/app/(main)/tanabana/services/common/AuthService';

const AppTopbar = forwardRef<AppTopbarRef>((props, ref) => {
    const service: AuthService = new AuthService();
    const router = useRouter();
    const { layoutConfig, layoutState, onMenuToggle, showProfileSidebar } = useContext(LayoutContext);
    const menubuttonRef = useRef(null);
    const topbarmenuRef = useRef(null);
    const topbarmenubuttonRef = useRef(null);

    useImperativeHandle(ref, () => ({
        menubutton: menubuttonRef.current,
        topbarmenu: topbarmenuRef.current,
        topbarmenubutton: topbarmenubuttonRef.current
    }));

    const erpLogout = async () => {
        let isLogout: boolean = await service.erpLogout();
        if(isLogout) {
            let loginUrl = service.getERPLoginUrl();
            router.push(loginUrl);
        }
    };

    return (
        <div className="layout-topbar">
             <button ref={menubuttonRef} type="button" className="p-link layout-menu-button layout-topbar-button" onClick={onMenuToggle}>
                <i className="pi pi-bars" />
            </button>
            
            <Link href="/" className="layout-topbar-logo">
                {/*
                    <img src={`/layout/images/logo-${layoutConfig.colorScheme === 'light' ? 'dark' : 'white'}.svg`} alt="Sakai logo" className="mb-5 w-6rem flex-shrink-0" />
                    <img src={`/layout/images/logo.avif`} width="160px" height={'60px'} alt="logo" />
                    <h3 style={{color: '#fff', marginTop: '15px', marginLeft: '10px', fontFamily:'sans-serif', fontSize: '30px'}}>Hassan's</h3>
                */}
                <img src={`/layout/images/HassansLogo.png`} alt="logo" />
            </Link>

            <button ref={topbarmenubuttonRef} type="button" className="p-link layout-topbar-menu-button layout-topbar-button" onClick={showProfileSidebar}>
                <i className="pi pi-ellipsis-v" />
            </button>

            <div ref={topbarmenuRef} className={classNames('layout-topbar-menu', { 'layout-topbar-menu-mobile-active': layoutState.profileSidebarVisible })}>
                <button type="button" className="p-link layout-topbar-button">
                    <i className="pi pi-bell"></i>
                    <span>Notifications</span>
                </button>
                <button type="button" className="p-link layout-topbar-button" onClick={erpLogout}>
                    <i className="pi pi-user"></i>
                    <span>Profile</span>
                </button>
                
            </div>
        </div>
    );
});

AppTopbar.displayName = 'AppTopbar';

export default AppTopbar;
