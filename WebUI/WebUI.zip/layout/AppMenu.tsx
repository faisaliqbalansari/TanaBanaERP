/* eslint-disable @next/next/no-img-element */

import React, { useContext } from 'react';
import AppMenuitem from './AppMenuitem';
import { LayoutContext } from './context/layoutcontext';
import { MenuProvider } from './context/menucontext';
import Link from 'next/link';
import { PanelMenu } from 'primereact/panelmenu';
import { MenuItem } from 'primereact/menuitem';
import { AppMenuItem } from '@/types';
import { useRouter } from "next/navigation";

const AppMenu = () => {
    const { layoutConfig } = useContext(LayoutContext);
    const router = useRouter();

    /*
    const model: AppMenuItem[] = [
        {
            label: 'Home',
            items: [{ label: 'Dashboard', icon: 'pi pi-fw pi-home', to: '/' }]
        },
        {
            label: 'UI Components',
            items: [
                { label: 'File', icon: 'pi pi-fw pi-id-card', to: '/uikit/formlayout' },
                { label: 'Input', icon: 'pi pi-fw pi-check-square', to: '/uikit/input' },
                { label: 'Float Label', icon: 'pi pi-fw pi-bookmark', to: '/uikit/floatlabel' },
                { label: 'Invalid State', icon: 'pi pi-fw pi-exclamation-circle', to: '/uikit/invalidstate' },
                { label: 'Button', icon: 'pi pi-fw pi-mobile', to: '/uikit/button', class: 'rotated-icon' },
                { label: 'Table', icon: 'pi pi-fw pi-table', to: '/uikit/table' },
                { label: 'List', icon: 'pi pi-fw pi-list', to: '/uikit/list' },
                { label: 'Tree', icon: 'pi pi-fw pi-share-alt', to: '/uikit/tree' },
                { label: 'Panel', icon: 'pi pi-fw pi-tablet', to: '/uikit/panel' },
                { label: 'Overlay', icon: 'pi pi-fw pi-clone', to: '/uikit/overlay' },
                { label: 'Media', icon: 'pi pi-fw pi-image', to: '/uikit/media' },
                { label: 'Menu', icon: 'pi pi-fw pi-bars', to: '/uikit/menu', preventExact: true },
                { label: 'Message', icon: 'pi pi-fw pi-comment', to: '/uikit/message' },
                { label: 'File', icon: 'pi pi-fw pi-file', to: '/uikit/file' },
                { label: 'Chart', icon: 'pi pi-fw pi-chart-bar', to: '/uikit/charts' },
                { label: 'Misc', icon: 'pi pi-fw pi-circle', to: '/uikit/misc' }
            ]
        },
        {
            label: 'Prime Blocks',
            items: [
                { label: 'Free Blocks', icon: 'pi pi-fw pi-eye', to: '/blocks', badge: 'NEW' },
                { label: 'All Blocks', icon: 'pi pi-fw pi-globe', url: 'https://blocks.primereact.org', target: '_blank' }
            ]
        },
        {
            label: 'Utilities',
            items: [
                { label: 'PrimeIcons', icon: 'pi pi-fw pi-prime', to: '/utilities/icons' },
                { label: 'PrimeFlex', icon: 'pi pi-fw pi-desktop', url: 'https://primeflex.org/', target: '_blank' }
            ]
        },
        {
            label: 'Pages',
            icon: 'pi pi-fw pi-briefcase',
            to: '/pages',
            items: [
                {
                    label: 'Landing',
                    icon: 'pi pi-fw pi-globe',
                    to: '/landing'
                },
                {
                    label: 'Auth',
                    icon: 'pi pi-fw pi-user',
                    items: [
                        {
                            label: 'Login',
                            icon: 'pi pi-fw pi-sign-in',
                            to: '/auth/login'
                        },
                        {
                            label: 'Error',
                            icon: 'pi pi-fw pi-times-circle',
                            to: '/auth/error'
                        },
                        {
                            label: 'Access Denied',
                            icon: 'pi pi-fw pi-lock',
                            to: '/auth/access'
                        }
                    ]
                },
                {
                    label: 'Crud',
                    icon: 'pi pi-fw pi-pencil',
                    to: '/pages/crud'
                },
                {
                    label: 'Timeline',
                    icon: 'pi pi-fw pi-calendar',
                    to: '/pages/timeline'
                },
                {
                    label: 'Not Found',
                    icon: 'pi pi-fw pi-exclamation-circle',
                    to: '/pages/notfound'
                },
                {
                    label: 'Empty',
                    icon: 'pi pi-fw pi-circle-off',
                    to: '/pages/empty'
                }
            ]
        },
        {
            label: 'Hierarchy',
            items: [
                {
                    label: 'Submenu 1',
                    icon: 'pi pi-fw pi-bookmark',
                    items: [
                        {
                            label: 'Submenu 1.1',
                            icon: 'pi pi-fw pi-bookmark',
                            items: [
                                { label: 'Submenu 1.1.1', icon: 'pi pi-fw pi-bookmark' },
                                { label: 'Submenu 1.1.2', icon: 'pi pi-fw pi-bookmark' },
                                { label: 'Submenu 1.1.3', icon: 'pi pi-fw pi-bookmark' }
                            ]
                        },
                        {
                            label: 'Submenu 1.2',
                            icon: 'pi pi-fw pi-bookmark',
                            items: [{ label: 'Submenu 1.2.1', icon: 'pi pi-fw pi-bookmark' }]
                        }
                    ]
                },
                {
                    label: 'Submenu 2',
                    icon: 'pi pi-fw pi-bookmark',
                    items: [
                        {
                            label: 'Submenu 2.1',
                            icon: 'pi pi-fw pi-bookmark',
                            items: [
                                { label: 'Submenu 2.1.1', icon: 'pi pi-fw pi-bookmark' },
                                { label: 'Submenu 2.1.2', icon: 'pi pi-fw pi-bookmark' }
                            ]
                        },
                        {
                            label: 'Submenu 2.2',
                            icon: 'pi pi-fw pi-bookmark',
                            items: [{ label: 'Submenu 2.2.1', icon: 'pi pi-fw pi-bookmark' }]
                        }
                    ]
                }
            ]
        },
        {
            label: 'Get Started',
            items: [
                {
                    label: 'Documentation',
                    icon: 'pi pi-fw pi-question',
                    to: '/documentation'
                },
                {
                    label: 'Figma',
                    url: 'https://www.dropbox.com/scl/fi/bhfwymnk8wu0g5530ceas/sakai-2023.fig?rlkey=u0c8n6xgn44db9t4zkd1brr3l&dl=0',
                    icon: 'pi pi-fw pi-pencil',
                    target: '_blank'
                },
                {
                    label: 'View Source',
                    icon: 'pi pi-fw pi-search',
                    url: 'https://github.com/primefaces/sakai-react',
                    target: '_blank'
                }
            ]
        }
    ];
    */
    const model: AppMenuItem[] = [
        {
            label: '',
            items: [
                {
                    label: 'Dashboard',
                    icon: 'pi pi-home',
                    command: () => {
                        router.push('/');
                     }
                },
                {
                    label: 'Adminstration',
                    icon: 'pi pi-cog',
                    items: [
                        {
                            label: 'Master Setup',
                            icon: 'pi pi-wrench',
                            items: [
                                {
                                    label: 'Countries', 
                                    icon: 'pi pi-fw pi-globe',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/countries');
                                     }
                                },
                                {
                                    label: 'States/Provinces',
                                    icon: 'pi pi-fw pi-map',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/provinces');
                                     }
                                },
                                {
                                    label: 'Cities',
                                    icon: 'pi pi-fw pi-home',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/cities');
                                     }
                                },
                                {
                                    label: 'Areas',
                                    icon: 'pi pi-fw pi-compass',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/areas');
                                     }
                                },
                                {
                                    label: 'Machine Types',
                                    icon: 'pi pi-fw pi-desktop',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/machine-types');
                                     }
                                },
                                {
                                    label: 'Machine Configuration',
                                    icon: 'pi pi-fw pi-cog',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/machine-configurations');
                                     }
                                },
                                {
                                    label: 'Service Types',
                                    icon: 'pi pi-fw pi-cog',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/service-types');
                                     }
                                },
                                {
                                    label: 'Unit of Measure',
                                    icon: 'pi pi-fw pi-cog',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/unit-of-measure');
                                     }
                                }
                            ]
                        },
                        
                    {
                        label: 'User Administration', icon:'pi pi-users',
                        items: [ 
                            {
                                label:'User', 
                                icon: 'pi pi-user', 
                                command: () => {
                                    router.push('/tanabana/modules/administration/user-administration/users');
                                 }
                            },
                            {
                                label:'User Roles', 
                                icon: 'pi pi-lock', 
                                command: () => {
                                    router.push('/tanabana/modules/administration/user-administration/user-roles');
                                 }
                            },

                        ]
                    },
                    {
                        label: 'System Administration', icon: 'pi pi-server',
                        items: [ 
                            {
                                label:'System Setting',
                                icon: 'pi pi-fw pi-wrench', 
                                command: () => {
                                    router.push('/tanabana/modules/administration/system-administration/system-settings');
                                 }
                            } 
                        ]
                    }
                ]
                }, 
                {
                    label: 'Inventory', icon: 'pi pi-th-large',
                    items: [
                    { 
                        label: 'Design Library', icon: 'pi pi-palette',
                        items: [ 
                         
                            {
                                label:'Design Types',
                                icon: 'pi pi-pencil', 
                                command: () => {
                                    router.push('/tanabana/modules/inventory/desing-library/desing-types');
                                 }
                            },
                            {
                                label:'Designs',
                                 icon: 'pi pi-file-edit', 
                                 command: () => {
                                    router.push('/tanabana/modules/inventory/desing-library/desings');
                                 }
                            }
                           
                        ]
                    },
                    { 
                        label: 'Material Library', icon: 'pi pi-list',
                        items: [ 
                         
                            {
                                label:'Material Categories',
                                 icon: 'pi pi-chart-pie', 
                                 command: () => {
                                    router.push('/tanabana/modules/inventory/material-library/material-categories');
                                 }
                            },
                            {
                                label:'Material subcategories', 
                                icon: 'pi pi-chart-pie', 
                                command: () => {
                                    router.push('/tanabana/modules/inventory/material-library/material-subcategories');
                                 }
                            },
                            {
                                label:'Material Attributes', 
                                icon: 'pi pi-tags',
                                command: () => {
                                    router.push('/tanabana/modules/inventory/material-library/material-attributes');
                                 }
                            },
                            {
                                label:'Materials',
                                 icon: 'pi pi-slack', 
                                 command: () => {
                                    router.push('/tanabana/modules/inventory/material-library/materials');
                                 }
                            },
                            {
                                label:'Material Prices',
                                 icon: 'pi pi-dollar', 
                                 command: () => {
                                    router.push('/tanabana/modules/inventory/material-library/material-price');
                                 }
                            }
                        ]
                    },
                    { 
                        label: 'Product Library', icon: 'pi pi-align-justify',
                        items: [ 
                         
                            {
                                label:'Product Categories',
                                 icon: 'pi pi-chart-pie', 
                                 command: () => {
                                    router.push('/tanabana/modules/inventory/product-library/product-categories');
                                 }
                            },
                            {
                                label:'Product Subcategories', 
                                icon: 'pi pi-chart-pie', 
                                command: () => {
                                    router.push('/tanabana/modules/inventory/product-library/product-subcategories');
                                 }
                            },
                            {
                                label:'Product Attributes',
                                 icon: 'pi pi-tags', 
                                 command: () => {
                                    router.push('/tanabana/modules/inventory/product-library/product-attributes');
                                 }
                            },
                            {
                                label:'Products',
                                 icon: 'pi pi-th-large', 
                                 command: () => {
                                    router.push('/tanabana/modules/inventory/product-library/products');
                                 }
                            },
                            {
                                label:'Product Prices',
                                 icon: 'pi pi-dollar', 
                                 command: () => {
                                    router.push('/tanabana/modules/inventory/product-library/product-prices');
                                 }
                            }
                           
                           
                        ]
                    },
                ]
                },
                {
                    label: "Production", icon: 'pi pi-fw pi-chart-bar',
                    items: [ 
                         
                        {
                            label:'Production Masters', icon: 'pi pi-wrench', 
                            items: [ 
                         
                                {
                                    label:'Service Providers', 
                                    icon: 'pi pi-fw pi-truck', 
                                    command: () => {
                                        router.push('/tanabana/modules/production/production-masters/service-providers');
                                     }
                                },
                                {
                                    label:'Factories',
                                     icon: 'pi pi-fw pi-home', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/production-masters/factories');
                                     }
                                },
                                {
                                    label:'Machines', 
                                    icon: 'pi pi-fw pi-wrench', 
                                    command: () => {
                                        router.push('/tanabana/modules/production/production-masters/machines');
                                     }
                                },
                                {
                                    label:'Job Types',
                                     icon: 'pi pi-fw pi-sliders-h', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/production-masters/job-types');
                                     }
                                },
                                {
                                    label:'Job Phases',
                                     icon: 'pi pi-fw pi-sliders-v', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/production-masters/job-phase');
                                     }
                                }
                               
                               
                            ]
                        },
                        {
                            label:'Production Management',
                             icon: 'pi pi-sitemap', 
                             
                            items:[
                                {
                                    label:'Job Plans',
                                     icon: 'pi pi-fw pi-user-plus', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/production-management/job-plans');
                                     }
                                },
                                {
                                    label:'Job Phases/Assingments',
                                     icon: 'pi pi-fw pi-briefcase', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/production-management/job-phases-assingnments');
                                     }
                                },
                                {
                                    label:'Job Processing', 
                                    icon: 'pi pi-fw pi-sort-alt', 
                                    command: () => {
                                        router.push('/tanabana/modules/production/production-management/job-processing');
                                     }
                                }
                            ]
                        },
                        /*
                        {
                            label:'Reports', icon: 'pi pi-book', 
                            items:[
                                {
                                    label:'Material Inventory',
                                     icon: 'pi pi-chart-line', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/reports/material-inventory');
                                     }
                                },
                                {
                                    label:'Product Inventory',
                                     icon: 'pi pi-chart-line', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/reports/material-inventory');
                                     }
                                },
                                {
                                    label:'Job Reports',
                                     icon: 'pi pi-chart-line', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/reports/material-inventory');
                                     }
                                }
                            ]
                        },
                        */
                        {
                            label:'Reports', icon: 'pi pi-book', 
                            items:[
                                {
                                    label:'Material Inventory',
                                     icon: 'pi pi-chart-line', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/reports/material-inventory');
                                     }
                                },
                                {
                                    label:'Product Inventory',
                                     icon: 'pi pi-chart-line', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/reports/material-inventory');
                                     }
                                },
                                {
                                    label:'Job Reports',
                                     icon: 'pi pi-chart-line', 
                                     command: () => {
                                        router.push('/tanabana/modules/production/reports/material-inventory');
                                     }
                                }
                            ]
                        },
                        
                        
                      
                       
                       
                    ]
                },
                {
                    label: 'Warehouse',
                    icon: 'pi pi-truck',
                    items: [
                        {
                            label: 'Setup',
                            icon: 'pi pi-wrench',
                            items: [
                                {
                                    label: 'Warehouses', 
                                    icon: 'pi pi-fw pi-globe',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/countries');
                                     }
                                },
                            ]
                        },
                        {
                            label: 'Operations',
                            icon: 'pi pi-cog',
                            items: [
                                {
                                    label: 'Dispatch',
                                    icon: 'pi pi-chevron-right',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/countries');
                                     }
                                },
                                {
                                    label: 'Recieve',
                                    icon: 'pi pi-chevron-left',
                                    command: () => {
                                        router.push('/tanabana/modules/administration/master-setup/countries');
                                     }
                                }
                            ]
                        }
                    ]
                },
                {
                    label: 'Sales',
                    icon: 'pi pi-sort-amount-up',
                    
                },
                {
                    label: 'Accounting',
                    icon: 'pi pi-wallet',
                    
                },
            ]
        }
    ];

    return (
        <MenuProvider>
            <ul className="layout-menu">
                {model.map((item, i) => {
                    return !item?.seperator ? <AppMenuitem item={item} root={true} index={i} key={item.label} className='' /> : <li className="menu-separator"></li>;
                })}

            </ul>
        </MenuProvider>
    );
};

export default AppMenu;
